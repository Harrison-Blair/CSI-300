drop database if exists imdb;
create database if not exists imdb;

use imdb;

CREATE TABLE IF NOT EXISTS movies (
  id int(11) NOT NULL AUTO_INCREMENT,
  title varchar(255) NOT NULL,
  PRIMARY KEY (id)
) AUTO_INCREMENT=4;

INSERT INTO movies (id, title) VALUES
(1, 'Harry Potter'),
(2, 'Lord of the Rings'),
(3, 'Rise of the Silver Surfer');

CREATE TABLE IF NOT EXISTS users (
  id int(11) NOT NULL AUTO_INCREMENT,
  username varchar(255) NOT NULL,
  password varchar(32) NOT NULL,
  email varchar(255) NOT NULL,
  PRIMARY KEY (id)
) AUTO_INCREMENT=3 ;

INSERT INTO users (id, username, password, email) VALUES
(1, 'admin', 'qewrtqwert', 'admin@imdb.com'),
(2, 'user', 'secret', 'mylittlepony@stupid.com');