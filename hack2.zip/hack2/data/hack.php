<?php
require("db_connect.php");

$q = $_GET['q'];
if ($q != "") {
    $query ="SELECT * FROM movies WHERE title='$q'";
	$result = mysqli_query($link,$query);
    if (!$result) {
        die('MySQL query error: ' . mysqli_error($link));
    }
    echo "Found ".mysqli_num_rows($result)."movies:<br/>";
    while ($row = mysqli_fetch_assoc($result)) {
        echo $row["id"].": ".$row["title"]."<br/>";
    }
}
?>
