<?php
require("../data/db_connect2.php");
echo'
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>SQL Injection Form Error Example</title>
	<meta name="description" content="Twitter Bootstrap Version2.0 form error example from w3resource.com."> <link href="http://localhost/twitter-bootstrap/twitter-bootstrap-v2/docs/assets/css/bootstrap.css" rel="stylesheet">
 </head>
<body style="margin-top: 50px">
	<div class="container">
	<div class="row">
	<div class="span6">
';
	$uid = $_POST['uid'];
	$pid = $_POST['passid'];
	
	$query = "select cid,cusername,cpswd from CustomerLogIn where cusername = '$uid' and 
			  cpswd = '$pid'";
	$result =  mysqli_query($link,$query)
				or die("Error: ".mysqli_error($link));
		echo"<h4>".
			"-- Personal Information -- </h4>",
			"</br>";
		while ($row=mysqli_fetch_array($result))
		{
			echo "<p>"."User ID : ".$row['cid']."</p>";
			echo "<p>"."Username : ".$row['cusername']."</p>";
			echo "<p>"."Password : ".$row['cpswd']."</p>";
			echo "--------------------------------------------";
		}
	
echo'
</div>
</div>
</div>
</body>
</html>
';
?>