<form method="get" action="../data/hack.php">
  <input type="text" name="q"/>
  <input type="submit" />
</form>

<!-- In the form field, enter: ' OR '1'='1 as the movie name -->