<?php
include("./include/header1.inc");
echo"<title>Home Page for Employee Data</title>";
include("./include/header2_hp.inc");

include("./include/navhp.inc");
include("./include/text.inc");
include("./include/nav_footer.inc");

?>