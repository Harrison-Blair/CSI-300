<?php
require("../data/db_connect.php");
$eid = $_COOKIE['eid'];
$fn = $_COOKIE['first_name'];
$ln = $_COOKIE['last_name'];
$street = $_COOKIE['street'];
$city = $_COOKIE['city'];
$st = $_COOKIE['st'];
$zip = $_COOKIE['zip'];
$address = $street."<br />";
$address .= $city.", ".$st."  ".$zip;
$phone = "(";
$phone .= $_COOKIE['code'];
$phone .= ") ";
$phone .= $_COOKIE['exch'];
$phone .= " - ";
$phone .= $_COOKIE['num'];
$em = $_COOKIE['em'];
$sal = $_COOKIE['sal'];
$dept = $_COOKIE['dept'];
$pos = $_COOKIE['pos'];
$comm = $_COOKIE['comm'];
$status = $_COOKIE['estat'];


$sql = "Select pos_name from EmpPos where pos_id=".$pos;
$result =  mysqli_query($link,$sql);
while($row = mysqli_fetch_array($result))
					{			
						$pos = $row['pos_name'];
					}
$sql2 = "Select dept_name from Department where dept_id=".$dept;
$result2 =  mysqli_query($link,$sql2);
while($row = mysqli_fetch_array($result2))
					{			
						$dept = $row['dept_name'];
					}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add An Employee</title>
	<link type="text/css" href="../common/style.css" rel="stylesheet" />
	<link type="text/css" href="../common/form_val.css" rel="stylesheet" />
	<script type="text/javascript" src="../common/emp_val.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="container">
<form name="employee" action="insert_emp.php" method="post">
	<table>
		<tr>
			<td colspan="2" id="tableTitle">
				Confirm Employee Input 
			</td>
		</tr>
		<tr>
			<td colspan="2">
				OK moron, this is your last chance to get it right. You screw this up, we will
				find out where you live...
			</td>
		</tr>
    	<tr>
        	<td class="labels">Employee ID:</td>
            <td class="data">
			<?php echo $eid; ?>
			</td>
        </tr>
		<tr>
        	<td class="labels">First Name:</td>
            <td class="data"><?php echo $fn; ?></td>
        </tr>
		<tr>
        	<td class="labels">Last Name:</td>
            <td class="data"><?php echo $ln; ?></td>
        </tr>
		<tr>
        	<td class="labels">Street:</td>
            <td class="data"><?php echo $street; ?></td>
        </tr>
		<tr>
        	<td class="labels">City:</td>
            <td class="data"><?php echo $eid; ?></td>
        </tr>
        <tr>
        	<td class="labels">State:</td>
            <td class="data"><?php echo $st; ?></td>
        </tr>
        <tr>
        	<td class="labels">Zip:</td>
            <td class="data"><?php echo $zip; ?></td>
        </tr>
		<tr>
        	<td class="labels">E-Mail Address:</td>
            <td class="data"><?php echo $em; ?></td>
        </tr>
		<tr>
        	<td class="labels">Phone Number:</td>
            <td class="data">
				<?php echo $phone ?>
			</td>
        </tr>
		<tr>
        	<td class="labels">Salary:</td>
            <td class="data">$<?php echo $sal; ?></td>
        </tr>
		<tr>
        	<td class="labels">Department:</td>
            <td class="data"><?php echo $dept; ?></td>
        </tr>
		<tr>
        	<td class="labels">Position:</td>
            <td class="data"><?php echo $pos; ?></td>
        </tr>
		<tr>
        	<td class="labels">Comments:</td>
            <td class="data"><?php echo $comm; ?></td>
        </tr>
		<tr>
        	<td class="labels">Status:</td>
            <td class="data"><?php echo $status; ?></td>
        </tr>
		 <tr>
        	<td colspan="2" style="text-align:center;">
            	<input type="submit" name="s" value="Submit Data" />
           
            	<input type="reset" name="r" value="Clear Data" />
            </td>
        </tr>
	</table>
</form>
		
