<?php
require("../data/db_connect.php");
if(isset($_POST['dept']) or !empty($_POST['dept']))
	{
		$dept = $_POST['dept'];
	}
else
	{
		$dept = 0;
	}

$sql1 = "select pos_id,pos_name from EmpPos where dept_id=".$dept;
$result1 = mysqli_query($link,$sql1);

$sql2 = "select status_id,status_desc from HistoryStatus";
$result2 = mysqli_query($link,$sql2);
echo'
<!DOCTYPE html>
<html>
<head>
	<title>Add An Employee - Page 2</title>
	<link type="text/css" href="../common/style.css" rel="stylesheet" />
	<link type="text/css" href="../common/form_val.css" rel="stylesheet" />
	<script type="text/javascript" src="../common/emp_val.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="container">
<nav class="floating-menu1">
<h2>Floating Menu 1</h2>

<a href="../index.php">Home</a>
<a href="#">Add An Employee</a>
<a href="../php/view_all_emps.php">View All Employees</a>
<a href="delete_emp.htm">Delete An Employee</a>
<a href="update_emp.htm">Update An Employee</a>

</nav>

	<form name="employee3" action="add_emp_data.php" onsubmit="return val_data3();" method="post">
	<table>
		<tr>
			<td colspan="2" id="tableTitle">
				New Employee Input Form
			</td>
		</tr>
		<tr>
			<td class="labels">Position:</td>
            <td class="data">
				<select name="pos">
					<option value="">Choose One</option>
';
					while($row = mysqli_fetch_assoc($result1))
					{
						echo"<option value='".$row['pos_id']."' >".$row['pos_name']."</option>";
					}

echo'
				</select>
			</td>
		</tr>
		<tr>
			<td class="labels">Comments:</td>
            <td class="data">
				<textarea name="comments" rows="15" cols="40"></textarea>
			</td>
		</tr>
		<tr>
			<td class="labels">Employee Status:</td>
            <td class="data">
				<select name="empstatus">
					<option value="">Choose One</option>
';
					while($row = mysqli_fetch_assoc($result2))
					{
						echo"<option value='".$row['status_id']."' >".$row['status_desc']."</option>";
					}

echo'
				</select>
			</td>
		</tr>
		<tr>
        	<td colspan="2" style="text-align:center;">
            	<input type="submit" name="s" value="Continue">
           
            	<input type="reset" name="r" value="Clear Data">
            </td>
        </tr>
	</table>
    </form>
';