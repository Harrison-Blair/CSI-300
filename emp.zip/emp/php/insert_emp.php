<?php
require("../data/db_connect.php");
$eid = $_COOKIE['eid'];
$fn = $_COOKIE['first_name'];
$ln = $_COOKIE['last_name'];
$street = $_COOKIE['street'];
$city = $_COOKIE['city'];
$st = $_COOKIE['st'];
$zip = $_COOKIE['zip'];
$address = $street."<br />";
$address .= $city.", ".$st."  ".$zip;
$phone = "(";
$phone .= $_COOKIE['code'];
$phone .= ") ";
$phone .= $_COOKIE['exch'];
$phone .= " - ";
$phone .= $_COOKIE['num'];
$em = $_COOKIE['em'];
$sal = $_COOKIE['sal'];
$dept = $_COOKIE['dept'];
$pos = $_COOKIE['pos'];
$comm = $_COOKIE['comm'];
$status = $_COOKIE['estat'];

$sql = "Insert into Employee values($eid,'$fn','$ln')";
$result =  mysqli_query($link,$sql);

$sql2 = "Insert into Address values($eid,'$street','$city','$st','$zip',$eid)";
$result2 =  mysqli_query($link,$sql2);

$sql3 = "Insert into EmpContact values($eid,1,'$phone')";
$result3 =  mysqli_query($link,$sql3);

$sql4 = "Insert into EmpContact values($eid,2,'$em')";
$result4 =  mysqli_query($link,$sql4);

$sql5 = "Insert into EmpHistory values($eid,$pos,NOW(),$sal,'$comm',$status)";
$result5 =  mysqli_query($link,$sql5);

header("Location: confirm_emp_insert.php");
?>
