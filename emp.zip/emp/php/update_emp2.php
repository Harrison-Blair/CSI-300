<?php
require("../data/db_connect.php");

$empid = $_POST['empid'];
$sp = $_POST['sp'];

include("../include/header1.inc");
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add An Employee</title>
	<link type="text/css" href="../common/style.css" rel="stylesheet" />
	<link type="text/css" href="../common/form_val.css" rel="stylesheet" />
	<script type="text/javascript" src="../common/update_val.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="container">
<nav class="floating-menu1">
<h2>Floating Menu 1</h2>

<a href="../index.php">Home</a>
<a href="#">Add An Employee</a>
<a href="../php/choose_all_emps.php">View All Employees</a>
<a href="delete_emp.htm">Delete An Employee</a>
<a href="update_emp.htm">Update An Employee</a>

</nav>
';
<?php
if($sp == "add")
{
	$sql = "select e.eid,efn,eln,estreet,ecity,est,ezip
			from Employee e join Address a on e.eid = a.eid 
			where e.eid =".$empid;
	$result =  mysqli_query($link,$sql);
	echo'
	<form name="update" action="update_emp3.php" onsubmit="return update_data();" method="post" >
		<input type = "hidden" value = "1" name = "check" />
		<input type = "hidden" value = "add" name = "sp" />		
	<table>
		<tr>
			<td id="tableTitle" colspan="3">Employee Update Information</td>
		<tr>
		<tr>
			<td>Emp ID</td>
			<td>Employee Name</td>
			<td>Address</td>
		</tr>';
		while($row = mysqli_fetch_assoc($result))
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>
						  <input type = 'hidden' value = '".$row['eid']."' name = 'eid' /> 
						  <input name='estreet' value='".$row['estreet']."'>
						  <input name='ecity' value = '".$row['ecity']."'>
						  <input name='estate' size = '2' maxlength = '2' value = '".$row['est']."'>
						  <input name='ezip' size = '5' maxlength = '5' value = '".$row['ezip']."'></td></tr>";
			}
	echo'
		<tr>
			<td colspan="3">
				<input type="submit" name="s" value="Continue Update">
			</td>
		</tr>
	</table></form>';
}

elseif($sp == "pos")
{
	$sql = "select e.eid,efn,eln,pos_name,ep.pos_id,salary
			from Employee e join EmpHistory eh join EmpPos ep
			on e.eid = eh.eid and eh.pos_id = ep.pos_id
			where e.eid = ".$empid;
	$result =  mysqli_query($link,$sql);
	echo'
	<form name="update" action="update_emp3.php" onsubmit="return update_data();" method="post" > 
	<input type = "hidden" value = "2" name = "check" />
	<input type = "hidden" value = "pos" name = "sp" />
	<table>
		<tr>
			<td id="tableTitle" colspan="4">Employee Update Information</td>
		<tr>
		<tr>
			<td>Emp ID</td>
			<td>Employee Name</td>
			<td>Position Name</td>
			<td>Position ID</td>
			<td>Salary</td>
		</tr>';
		while($row = mysqli_fetch_assoc($result))
			{			
				echo "	<tr>
						<input type = 'hidden' value = '".$row['eid']."' name = 'eid' />
						<input type = 'hidden' value = '".$row['pos_id']."' name = 'curr_pos_id' />
						<td>".$row['eid']."</td>
						<td>".$row['efn']." ".$row['eln']."</td>
						<td>".$row['pos_name']."</td>
						<td>".$row['pos_id']."</td>
						<td>$".number_format($row['salary'])."</td></tr>";
			}
		$sql2 = "select ep.pos_id,ep.pos_name
			from EmpPos ep where pos_id <100";
		$result2 =  mysqli_query($link,$sql2);
		
		$sql3 = "select * from HistoryStatus";
		$result3 =  mysqli_query($link,$sql3);
	echo'
		<tr>
			<td>Enter new position:
				<select name="posid">
				<option value="0">Position</option>';
				while($row = mysqli_fetch_assoc($result2))
				{
					echo"<option value='".$row['pos_id']."' >".$row['pos_name']."</option>";
				}
echo'	
				</select>
			</td>
			<td>
				New Salary:<input name="new_sal" size="6" />
			</td>
			<td>Enter reason for the update:
				<select name="stat">
				<option value="0">Select Status</option>';
				while($row = mysqli_fetch_assoc($result3))
				{
					echo"<option value='".$row['status_id']."' >".$row['status_desc']."</option>";
				}
echo'	
				</select>
			</td>
			<td>Enter comments:
				<textarea name="comm" rows="5" cols = "20"></textarea>
			</td>
		</tr>
		<tr>
			<td colspan="4">
				<input type="submit" name="s" value="Continue Update">
			</td>
		</tr>
	</table></form>';
}

include("../include/nav_footer.inc");
?>