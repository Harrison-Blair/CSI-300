<?php
require("../data/db_connect.php");
$sql = "Select MAX(eid) from Employee";
$result =  mysqli_query($link,$sql);
while($row = mysqli_fetch_array($result))
					{			
						$eid = $row['MAX(eid)']+1;
					}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add An Employee</title>
	<link type="text/css" href="../common/style.css" rel="stylesheet" />
	<link type="text/css" href="../common/form_val.css" rel="stylesheet" />
	<script type="text/javascript" src="../common/emp_val.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="container">
<nav class="floating-menu1">
<h2>Floating Menu 1</h2>

<a href="../index.php">Home</a>
<a href="#">Add An Employee</a>
<a href="../php/choose_all_emps.php">View All Employees</a>
<a href="delete_emp.htm">Delete An Employee</a>
<a href="update_emp.htm">Update An Employee</a>

</nav>

	<form name="employee" action="add_emp2" onsubmit="return val_data();" method="post">
	<table>
		<tr>
			<td colspan="2" id="tableTitle">
				New Employee Input Form
			</td>
		</tr>
    	<tr>
        	<td class="labels">Employee ID:</td>
            <td class="data">
			<?php
			echo $eid;
			echo"
			<input type='hidden' name='eid' value='";
			echo $eid;
			
			echo"' />";
			?>
			</td>
        </tr>
		<tr>
        	<td class="labels">First Name:</td>
            <td class="data"><input name="efn" size="20" ></td>
        </tr>
		<tr>
        	<td class="labels">Last Name:</td>
            <td class="data"><input name="eln" size="20" /></td>
        </tr>
		<tr>
        	<td class="labels">Street:</td>
            <td class="data"><input name="estreet" size="30" /></td>
        </tr>
		<tr>
        	<td class="labels">City:</td>
            <td class="data"><input name="ecity" size="30" /></td>
        </tr>
        <tr>
        	<td class="labels">State:</td>
            <td class="data"><input name="estate" size="2" maxlength="2" /></td>
        </tr>
        <tr>
        	<td class="labels">Zip:</td>
            <td class="data"><input name="ezip" size="5" maxlength="5" /></td>
        </tr>
		<tr>
        	<td class="labels">Phone Number:</td>
            <td class="data">
				(<input name="code" size="3" maxlength="3" />)
				 <input name="exch" size="3" maxlength="3" /> - 
				 <input name="num" size="4" maxlength="4" />
			</td>
        </tr>
		<tr>
        	<td class="labels">E-Mail Address:</td>
            <td class="data"><input name="em" size="35" /></td>
        </tr>
		<tr>
        	<td class="labels">Confirm E-Mail Address:</td>
            <td class="data"><input name="em2" size="35" /></td>
        </tr>
        <tr>
        	<td colspan="2" style="text-align:center;">
            	<input type="submit" name="s" value="Continue" />
           
            	<input type="reset" name="r" value="Clear Data" />
            </td>
        </tr>
	</table>
    </form>


<nav class="floating-menu2">

<a href="http://www.quackit.com/css/">CSS</a>
<a href="http://www.quackit.com/html/">HTML</a>
<a href="http://www.quackit.com/coldfusion/">ColdFusion</a>
<a href="http://www.quackit.com/database/">Database</a>

</nav>

</div>
</body>
</html>


?>
