<?php
require("../data/db_connect.php");
$choice = $_POST['choice'];
$filter = $_POST['by'];
/*
if(!null(filter) and !empty(filter))
{
	setFilter();
}

function setFilter($filter){
	
	switch ($filter) {
    case 11:
        "code to be executed if n=label1";
        break;
    case 22:
        "code to be executed if n=label1";
        break;
    case 33:
        "code to be executed if n=label1";
        break;
    default:
		echo"<h1>Your request could be processed, please try again later.</h1>";
	}
}
*/
include("../include/header1.inc");
echo'
	<title>View All Employees</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");

if($choice == 1)
{	
$sql = "select e.eid,efn,eln,pos_name, salary
from Employee e join EmpHistory eh join EmpPos ep join Department d
on e.eid=eh.eid and eh.pos_id = ep.pos_id and d.dept_id = ep.dept_id 
order by eid";
$result = mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id=\"tableTitle\" colspan=\"7\">All NEB Employees</td>
	<tr>
	<tr>
		<td>Emp ID</td>
		<td>Name</td>
		<td>Position</td>
		<td>Salary</td>
	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>".$row['pos_name']."</td>";
				echo "<td>$".number_format($row['salary'])."</td></tr>";
			}
echo"</table>";
}

elseif($choice == 2)
{	
$sql = "select e.eid,efn,eln,dept_name,salary
from Employee e join EmpPos ep join EmpHistory eh join Department d
on e.eid=ep.eid and ep.pos_id = eh.pos_id and d.dept_id = ep.dept_id 
order by eid asc";
$result =  mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id="tableTitle" colspan="7">All NEB Employees</td>
	<tr>
	<tr>
		<td>Emp ID</td>
		<td>Name</td>
		<td>Dept</td>
		<td>Salary</td>
	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>".$row['dept_name']."</td>";
				echo "<td>$".number_format($row['salary'])."</td></tr>";
			}
echo"</table>";
}

elseif($choice == 3)
{	
$sql = "select e.eid,efn,eln,pos_name,dept_name,salary
from Employee e join EmployeePosition ep join Position p join Department d
on e.eid=ep.eid and ep.pos_id = p.pos_id and d.dept_id = p.dept_id 
order by eid asc";
$result =  mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id="tableTitle" colspan="7">All NEB Employees</td>
	<tr>
	<tr>
		<td>Emp ID</td>
		<td>Name</td>
		<td>Position</td>
		<td>Dept</td>
		<td>Salary</td>
	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>".$row['pos_name']."</td>";
				echo "<td>".$row['dept_name']."</td>";
				echo "<td>$".number_format($row['salary'])."</td></tr>";
			}
echo"</table>";
}

elseif($choice == 4)
{	
$sql = "select distinct e.eid,efn,eln,pos_name,dept_name
from Employee e join EmpHistory eh join EmpPos ep join Department d
on e.eid=eh.eid and eh.pos_id = ep.pos_id and d.dept_id = ep.dept_id 
order by eid asc";
$result =  mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id="tableTitle" colspan="7">All NEB Employees</td>
	<tr>
	<tr>
		<td>Emp ID</td>
		<td>Name</td>
		<td>Position</td>
		<td>Dept</td>
	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>".$row['pos_name']."</td>";
				echo "<td>".$row['dept_name']."</td>";

			}
echo"</table>";
}

elseif($choice ==3)
{
$sql = "Select e.eid,efn,eln,contact from EmpContact ec join Employee e
		 on e.eid = ec.eid where contact_id = 1 order by eid asc";
$result =  mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id="tableTitle" colspan="7">All NEB Employees</td>
	<tr>
	<tr>
		<td>Emp ID</td>
		<td>Name</td>
		<td>Phone Number</td>

	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>".$row['contact']."</td></tr>";
			}
echo"</table>";
}

elseif($choice == 4)
{
$sql = "Select e.eid,efn,eln,contact from Contact c join Employee e
		 on e.eid = c.eid where contact_id=2 order by eid asc";
$result =  mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id="tableTitle" colspan="7">All NEB Employees</td>
	<tr>
	<tr>
		<td>Emp ID</td>
		<td>Name</td>
		<td>E-Mail Address</td>

	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>".$row['contact']."</td></tr>";
			}
echo"</table>";
}

elseif($choice == 5)
{	
$sql = "select e.eid,efn,eln,estreet,ecity,estate,ezip
from Employee e join EmpAddress ea 
on e.eaid=ea.eaid  
order by eid asc";
$result =  mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id="tableTitle" colspan="7">All NEB Employees</td>
	<tr>
	<tr>
		<td>Emp ID</td>
		<td>Name</td>
		<td>Address</td>
	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['eid']."</td>";
				echo "<td>".$row['efn']." ".$row['eln']."</td>";
				echo "<td>".$row['estreet']." ".$row['ecity'].", ";
				echo $row['estate']."  ".$row['ezip']."</td>";
			}
echo"</table>";
}

elseif($choice == 6)
{
$sql = "select dept_name,round(avg(salary)) as 'Avg Sal'
from EmployeePosition ep join Position p join Department d
on ep.pos_id = p.pos_id and d.dept_id = p.dept_id 

group by dept_name
order by round(avg(salary)) desc";
$result =  mysqli_query($link,$sql);
echo'
<table>
	<tr>
		<td id="tableTitle" colspan="7">All NEB Employees</td>
	<tr>
	<tr>
		<td>Department Name</td>
		<td>Average Salary</td>
	</tr>';
while($row = mysqli_fetch_assoc($result))
	
			{			
				echo "<tr>";
				echo "<td>".$row['dept_name']."</td>";
				
				echo "<td>$".number_format($row['Avg Sal'])."</td></tr>";
			}
echo"</table>";
}

else
{
	header("Location:sorry.php");
}
?>