<?php
require("../data/db_connect.php");
$sql1 = "select * from Department";
$result1 = mysqli_query($link,$sql1);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add An Employee - Page 2</title>
	<link type="text/css" href="../common/style.css" rel="stylesheet" />
	<link type="text/css" href="../common/form_val.css" rel="stylesheet" />
	<script type="text/javascript" src="../common/emp_val.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="container">
<nav class="floating-menu1">
<h2>Floating Menu 1</h2>

<a href="../index.php">Home</a>
<a href="#">Add An Employee</a>
<a href="../php/view_all_emps.php">View All Employees</a>
<a href="delete_emp.htm">Delete An Employee</a>
<a href="update_emp.htm">Update An Employee</a>

</nav>

	<form name="employee2" action="add_emp3.php" onsubmit="return val_data2();" method="post">
	<table>
		<tr>
			<td colspan="2" id="tableTitle">
				New Employee Input Form
			</td>
		</tr>

		
		<tr>
        	<td class="labels">Salary:</td>
            <td class="data"><input name="sal" size="12" ></td>
        </tr>
		<tr>
			<td class="labels">Department:</td>
            <td class="data">
				<select name="dept">
					<option value="">Choose One</option>
				<?php
					while($row = mysqli_fetch_assoc($result1))
					{
						echo"<option value='".$row['dept_id']."'>".$row['dept_name']."</option>";
					}
				?>
				</select>
			</td>
		</tr>
		 <tr>
        	<td colspan="2" style="text-align:center;">
            	<input type="submit" name="s" value="Continue">
           
            	<input type="reset" name="r" value="Clear Data">
            </td>
        </tr>
	</table>
    </form>


<nav class="floating-menu2">

<a href="http://www.quackit.com/css/">CSS</a>
<a href="http://www.quackit.com/html/">HTML</a>
<a href="http://www.quackit.com/coldfusion/">ColdFusion</a>
<a href="http://www.quackit.com/database/">Database</a>

</nav>

</div>
</body>
</html>

