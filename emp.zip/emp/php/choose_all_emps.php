<?php
require("../data/db_connect.php");
$sql = "select e.eid,efn,eln,estreet,ecity,est,ezip,pos_name,dept_name,salary
from Employee e join Address a join EmpHistory eh join EmpPos ep join Department d
on e.eid=a.eid and e.eid=eh.eid and eh.pos_id = ep.pos_id and d.dept_id = ep.dept_id 
order by eid asc";
$result =  mysqli_query($link,$sql);

$sql2 = "Select e.eid,efn,eln,contact from EmpContact ec join Employee e
		 on e.eid = ec.eid where contact_id=2 order by eid asc";
$result2 =  mysqli_query($link,$sql2);

include("../include/header1.inc");
echo'
	<title>View All Employees</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");
echo'
<form name="choice" action="view_all_emps.php" method="post">
<table>
	<tr>
		<td id="tableTitle" colspan="7">Options to view all employee data</td>
	<tr>
	<tr>
		<td>Choose Employees By</td>
		<td>
			<select name="choice">
				<option value="0">Choose One</option>
				<option value="1">Salary</option>
				<option value="1">Department Managers</option>
				<option value="3">Contact: Phone</option>
				<option value="4">Contact: E-Mail Address</option>
				<option value="5">Address</option>
				<option value="6">Average Salary/Department</option>
			</select>		
		</td>
	</tr>
	<tr>
		<td>Filter Employees By</td>
		<td>
			<select name="by">
				<option value="0">Choose One</option>
				<option value="11">All</option>
				<option value="22">Department: Phone</option>
				<option value="33">Position</option>
			</select>		
		</td>
	</tr>
	<tr>
        <td colspan="2" style="text-align:center;">
			<input type="submit" name="s" value="Continue">
			<input type="reset" name="r" value="Clear Data">
		</td>
	</tr>
</table>
</form>';


include("../include/nav_footer.inc");

?>