<?php
require("../data/db_connect.php");
$kill = $_POST['emp'];

$sql = "delete from employee where eid=".$kill;
$result =  mysqli_query($link,$sql);

header("Location:confirm_delete.php");

?>