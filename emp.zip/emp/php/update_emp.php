<?php
require("../data/db_connect.php");
$sql = "select eid,efn,eln from Employee order by eid";
$result =  mysqli_query($link,$sql);
include("../include/header1.inc");
echo'
	<title>Update An Employee</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");
echo'
<form name="update" action="update_emp2.php" method="post">
<table>
	<tr>
		<td colspan="2"><h1>Update Employee Information</h1></td>
	</tr>
	<tr>
		<td colspan="2" style="vertical-align:top">You are allowed to update the following information about an employee:
			<ul>
				<li>Address</li>
				<li>Position</li>
				<li>Salary</li>
			</ul>
			<p>Please be sure to complete all fields in order to assure a proper update of employee information.</p>
			<select name="empid">
				<option value="0">Choose An Employee</option>';
				while($row = mysqli_fetch_assoc($result))
				{
					echo"<option value='".$row['eid']."' >".$row['efn']." ".$row['eln']."</option>";
				}
echo'
				
			</select>
			<p>Choose the data you want to update:</p>
			<input type="radio" name="sp" value="add" />Address<br />
			<input type="radio" name="sp" value="pos" />Position/Salary<br />
			<p>
				<input type="submit" name="s" value="Continue Update">
				<input type="reset" name="r" value="Clear Data">
			</p>
		</td>
	</tr>
</table>
</form>
';



include("../include/nav_footer.inc");

?>