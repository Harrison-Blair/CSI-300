<?php
include("../include/header1.inc");
echo'
	<title>Sorry</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");
echo'
<table>
	<tr>
		<td>
			<h1>Tough break, you lose. This view is not available.</h1>
		</td>
	</tr>
</table>
';
include("../include/nav_footer.inc");
?>