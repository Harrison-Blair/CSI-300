<?php
require("../data/db_connect.php");
$sql = "select eid,efn,eln from Employee order by eid";
$result =  mysqli_query($link,$sql);


include("../include/header1.inc");
echo'
	<title>Delete An Employee</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");
echo'
<form name="delete" action="remove_emp.php" method="post">
<table>
	<tr>
		<td id="tableTitle" colspan="5">Delete an Employee</td>
	<tr>
	<tr>
		<td class="labels">Employees:</td>
        <td class="data">
			<select name="emp">
				<option value="">Choose One</option>';
				while($row = mysqli_fetch_assoc($result))
				{
					echo"<option value='".$row['eid']."' >".$row['efn']." ".$row['eln']."</option>";
				}
echo'
			</select>
		</td>
	</tr>
	<tr>
        <td colspan="2" style="text-align:center;">
			<input type="submit" name="s" value="Delete Employee">
			<input type="reset" name="r" value="Clear Data">
		</td>
	</tr>
</table>';


include("../include/nav_footer.inc");

?>