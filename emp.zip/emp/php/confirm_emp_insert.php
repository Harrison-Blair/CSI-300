<?php
require("../data/db_connect.php");
$eid = $_COOKIE['eid'];
$sql = "select e.eid,efn,eln,estreet,ecity,est,ezip,pos_name,dept_name,salary,
contact
from Employee e join Address ea join EmpContact ec join EmpHistory eh join EmpPos ep join Department d
on e.eid=ea.eaid and e.eid = ec.eid and e.eid=eh.eid and eh.pos_id = ep.pos_id and d.dept_id = ep.dept_id 
group by e.eid
order by eid desc limit 1";
$result =  mysqli_query($link,$sql);

$sql2 = "select contact from EmpContact where eid = ".$eid." and contact_id=1";
$result2 =  mysqli_query($link,$sql2);

$sql3 = "select contact from EmpContact where eid = ".$eid." and contact_id=2";
$result3 =  mysqli_query($link,$sql3);
echo'
<!DOCTYPE html>
<html>
<head>
	<title>New Employee Confirmation Page</title>
	<link type="text/css" href="../common/style.css" rel="stylesheet" />
	<link type="text/css" href="../common/form_val.css" rel="stylesheet" />
	<script type="text/javascript" src="../common/emp_val.js"></script>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body>
<div id="container">';
include("../include/nav.inc");


echo"
<table border='1'>
	<tr>
		<td colspan='2' id='tableTitle'>New Employee Confirmation Page</td>
	</tr>
	";
		while($row = mysqli_fetch_assoc($result))
			{			
				echo "<tr><td class='labels'>Employee ID</td><td class='data'>".$row['eid']."</td></tr>";
				echo "<tr><td class='labels'>First Name:</td><td class='data'>".$row['efn']."</td></tr>";
				echo "<tr><td class='labels'>Last Name:</td><td class='data'>".$row['eln']."</td></tr>";
				echo "<tr><td class='labels'>Street:</td><td class='data'>".$row['estreet']."</td></tr>";
				echo "<tr><td class='labels'>City:</td><td class='data'>".$row['ecity']."</td></tr>";
				echo "<tr><td class='labels'>State:</td><td class='data'>".$row['est']."</td></tr>";
				echo "<tr><td class='labels'>Zip Code:</td><td class='data'>".$row['ezip']."</td></tr>";
				echo "<tr><td class='labels'>Position:</td><td class='data'>".$row['pos_name']."</td></tr>";
				echo "<tr><td class='labels'>Department</td><td class='data'>".$row['dept_name']."</td></tr>";
				echo "<tr><td class='labels'>Salary:</td><td class='data'>".$row['salary']."</td></tr>";
			}
		while($row = mysqli_fetch_assoc($result2))
			{			
				echo "<tr><td class='labels'>Phone Number</td><td class='data'>".$row['contact']."</td></tr>";
			}
		while($row = mysqli_fetch_assoc($result3))
			{			
				echo "<tr><td class='labels'>E-Mail Address:</td><td class='data'>".$row['contact']."</td></tr>";
			}
		
		
?>
