<?php
include("../include/header1.inc");
echo'
	<title>View All Employees</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");
echo'
<table>
	<tr>
		<td id="tableTitle">You have successfully deleted the employee.</td>
	</tr>
</table>
';


include("../include/nav_footer.inc");

?>