<?php
require("../data/db_connect.php");
$check = $_POST['check'];
$eid = $_POST['eid'];

$sp = $_POST['sp'];
/**/
include("../include/header1.inc");
echo'
	<title>Update An Employee</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");

if($sp == "add" and $check == 1)
{
	$s = $_POST['estreet'];
	$c = $_POST['ecity'];
	$st = $_POST['estate'];
	$z = $_POST['ezip'];
	$c = $_POST['comm'];
	$sql = "update address set estreet = '".$s."' where eaid = ".$eid;
	$sql2 = "update address set ecity = '".$c."' where eaid = ".$eid;
	$sql3 = "update address set estate = '".$st."' where eaid = ".$eid;
	$sql4 = "update address set ezip = '".$z."' where eaid = ".$eid;
	$result =  mysqli_query($link,$sql);
	$result2 =  mysqli_query($link,$sql2);
	$result3 =  mysqli_query($link,$sql3);
	$result4 =  mysqli_query($link,$sql4);
	
	$sql5 = "select e.eid,efn,eln,estreet,ecity,estate,ezip
			from Employee e join Address a on e.eid = a.eid 
			where e.eid =".$eid;
	$result5 =  mysqli_query($link,$sql5);
	echo'
	<table>
		<tr>
			<td id="tableTitle" colspan="3">Updated Employee Adress</td>
		<tr>
		<tr>
			<td>Emp ID</td>
			<td>Employee Name</td>
			<td>Address</td>
		</tr>';
		while($row = mysqli_fetch_assoc($result5))
			{			
				echo "<tr>
					  <td>".$row['eid']."</td>
					  <td>".$row['efn']." ".$row['eln']."</td>
					  <td>".$row['estreet']." ".$row['ecity'].", ".$row['est']."  ".$row['ezip'].
					  "</td></tr>";
			}
	echo'
		
	</table>';
}

elseif($sp == "pos" and $check == 2)
{	
	$posid = $_POST['posid'];
	
	$new_sal = $_POST['new_sal'];
	$stat = $_POST['stat'];
	$comm = $_POST['comm'];
	
	$sqlA = "select eid from EmpHistory where eid = ".$eid;
	
	$resultA = mysqli_query($link,$sqlA);
	while($row = mysqli_fetch_assoc($resultA))
			{			
				$ep_eid = $row['eid'];
				setcookie("ep_eid",$ep_eid,time()+24*60*60*1000,"path='/'");
			}


	$sql = "Insert into EmpHistory values($eid,$pos_id,NOW(),$new_sal,'$comm',$stat)";
	$result = mysqli_query($link,$sql);

	
	header("Location:update_emp4.php");
}

include("../include/nav_footer.inc");
?>