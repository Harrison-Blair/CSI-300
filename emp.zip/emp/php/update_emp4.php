<?php
require("../data/db_connect.php");
$eid = $_COOKIE['ep_eid'];
include("../include/header1.inc");
echo'
	<title>Update An Employee</title>
	';
include("../include/header2.inc");

include("../include/nav.inc");

$sql = "select e.eid,efn,eln,pos_name,salary,status_desc
			from Employee e join EmpHistory eh join EmpPos ep join HistoryStatus hs
			on e.eid = eh.eid and ep.pos_id = eh.pos_id and eh.status_id = hs.status_id
			where e.eid = ".$eid;
	$result =  mysqli_query($link,$sql);
	echo'
	<table>
		<tr>
			<td id="tableTitle" colspan="4">Employee Update Information</td>
		<tr>
		<tr>
			<td>Emp ID</td>
			<td>Employee Name</td>
			<td>Position Name</td>
			<td>Salary</td>
			<td>Reason for Update</td>
		</tr>';
		while($row = mysqli_fetch_assoc($result))
			{			
				echo "	<tr>
						<td>".$row['eid']."</td>
						<td>".$row['efn']." ".$row['eln']."</td>
						<td>".$row['pos_name']."</td>
						<td>$".number_format($row['salary'])."</td>
						<td>".$row['status_desc']."</td></tr>";
			}
echo'
</table></form>';



include("../include/nav_footer.inc");
?>