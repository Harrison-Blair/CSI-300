<?php
$host = "localhost";
$user = "root";
$pass = "";
$db= "neb_customers";

$link1 = mysqli_connect($host,$user,$pass,$db); if ($link1->connect_errno>0) {
    die('Could not connect: ' . $db->error ); }

$db_selected = mysqli_select_db($link1, $db); if (!$db_selected) {
    die ('Can\'t use database $db : ' . $db->error); }
	
?>
