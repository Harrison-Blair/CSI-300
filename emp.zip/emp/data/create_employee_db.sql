-- MySQL Workbench Forward Engineering
Set session sql_mode=replace(@@sql_mode,'ONLY_FULL_GROUP_BY','');

-- -----------------------------------------------------
-- Schema employees
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `employees` ;

-- -----------------------------------------------------
-- Schema employees
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `employees` DEFAULT CHARACTER SET utf8 ;
USE `employees` ;

-- -----------------------------------------------------
-- Table `Employee`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Employee` ;

CREATE TABLE IF NOT EXISTS `Employee` (
  `eid` INT NOT NULL,
  `efn` VARCHAR(45) NOT NULL,
  `eln` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`eid`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Address`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Address` ;

CREATE TABLE IF NOT EXISTS `Address` (
  `eaid` INT NOT NULL,
  `estreet` VARCHAR(45) NOT NULL,
  `ecity` VARCHAR(45) NOT NULL,
  `est` CHAR(2) NOT NULL,
  `ezip` CHAR(5) NOT NULL,
  `eid` INT NOT NULL,
  PRIMARY KEY (`eaid`),
  CONSTRAINT `fk_Address_Employee`
    FOREIGN KEY (`eid`)
    REFERENCES `Employee` (`eid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `ContactType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `ContactType` ;

CREATE TABLE IF NOT EXISTS `ContactType` (
  `contact_id` INT NOT NULL,
  `contact_desc` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`contact_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EmpContact`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `EmpContact` ;

CREATE TABLE IF NOT EXISTS `EmpContact` (
  `eid` INT NOT NULL,
  `contact_id` INT NOT NULL,
  `contact` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`eid`, `contact_id`),
  CONSTRAINT `fk_Employee_has_Contact_Employee1`
    FOREIGN KEY (`eid`)
    REFERENCES `Employee` (`eid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_Employee_has_Contact_Contact1`
    FOREIGN KEY (`contact_id`)
    REFERENCES `ContactType` (`contact_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Department`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Department` ;

CREATE TABLE IF NOT EXISTS `Department` (
  `dept_id` INT NOT NULL,
  `dept_name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`dept_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EmpPos`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `EmpPos` ;

CREATE TABLE IF NOT EXISTS `EmpPos` (
  `pos_id` INT NOT NULL,
  `pos_name` VARCHAR(45) NOT NULL,
  `dept_id` INT NOT NULL,
  PRIMARY KEY (`pos_id`),
  CONSTRAINT `1`
    FOREIGN KEY (`dept_id`)
    REFERENCES `Department` (`dept_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `SalType`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `SalType` ;

CREATE TABLE IF NOT EXISTS `SalType` (
  `sal_id` INT NOT NULL,
  `sal_desc` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`sal_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `SalPos`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `SalPos` ;

CREATE TABLE IF NOT EXISTS `SalPos` (
  `pos_id` INT NOT NULL,
  `sal_id` INT NOT NULL,
  `sal_date` DATETIME NOT NULL,
  `sal_value` INT NOT NULL,
  PRIMARY KEY (`pos_id`, `sal_id`, `sal_date`),
  CONSTRAINT `2`
    FOREIGN KEY (`sal_id`)
    REFERENCES `SalType` (`sal_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `3`
    FOREIGN KEY (`pos_id`)
    REFERENCES `EmpPos` (`pos_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `HistoryStatus`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `HistoryStatus` ;

CREATE TABLE IF NOT EXISTS `HistoryStatus` (
  `status_id` INT NOT NULL,
  `status_desc` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`status_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `EmpHistory`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `EmpHistory` ;

CREATE TABLE IF NOT EXISTS `EmpHistory` (
  `eid` INT NOT NULL,
  `pos_id` INT NOT NULL,
  `start_date` DATETIME NOT NULL,
  `salary` INT NOT NULL,
  `comments` VARCHAR(255) NOT NULL,
  `status_id` INT NOT NULL,
  PRIMARY KEY (`eid`, `pos_id`, `start_date`),
  CONSTRAINT `4`
    FOREIGN KEY (`status_id`)
    REFERENCES `HistoryStatus` (`status_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `5`
    FOREIGN KEY (`eid`)
    REFERENCES `Employee` (`eid`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `6`
    FOREIGN KEY (`pos_id`)
    REFERENCES `EmpPos` (`pos_id`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

