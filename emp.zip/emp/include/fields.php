<?php
$sql1 = "select * from Department";
$result1 = mysqli_query($link,$sql1);

function sendIt(){
	if(isset($_GET["dept"]))
					{
						$dept=$_GET["dept"];
						echo "select country is => ".$dept;
       
						$sql2 = "select pos_id,pos_name from Position where pos_id = ".pid;
						$result2 = mysqli_query($link,$sql2);
		
	
						while($row = $result2->mysqli_fetch_assoc())
						{
							echo"<option value='".$row['pos_id']."' >".$row['pos_name']."</option>";
						}	
					}	

return ;					
}
echo'
		<tr>
        	<td class="labels">Department:</td>
            <td class="data">
				<select name="dept">
					<option value="">Choose One</option>
	';				
					 while($row = mysqli_fetch_assoc($result1)) {
				echo"<option value='".$row['dept_id']."' >".$row['dept_name']."</option>";
				
			}
	echo'
				</select>
			</td>
        </tr>
		<tr>
        	<td class="labels">Position:</td>
            <td class="data">
				<select name="pos">
					<option value="">Choose One</option>
					';
							
	echo'
				</select>
			</td>
        </tr>
		';