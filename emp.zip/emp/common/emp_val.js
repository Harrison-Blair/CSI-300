// JavaScript Document
	
function findCookie(val) {
    var cookie = null;
    var findVal = val + "=";
    var dc = document.cookie;
    if (dc.length > 0)
    {
       var start = dc.indexOf(findVal);
       if (start >= 0)
       {
          start += findVal.length;
          lastVal = dc.indexOf(";", start);
          if (lastVal == -1)
          {
             lastVal = dc.length;
          }
          cookie = (dc.substring(start, lastVal));
          }
          else
          {
             return cookie;
          }
        }
		return cookie;		
}


function val_data(){	
	var eid = document.employee.eid.value;
	var fn = document.employee.efn.value;
	var ln = document.employee.eln.value;
	var street = document.employee.estreet.value;
	var city = document.employee.ecity.value;
	var st = document.employee.estate.value.toUpperCase();
	var zip = document.employee.ezip.value;
	var code = document.employee.code.value;
	var exch = document.employee.exch.value;
	var num = document.employee.num.value;
	var em = document.employee.em.value;
	var em2 = document.employee.em2.value;
	
	var RegExpID = /^[1-9]{1}[0-9]$/;
	var RegExpText = /^[A-Z a-z]+$/;
	var RegExpAdd = /^[A-Z a-z 0-9]+$/;
	var RegExpST = /^[A-Za-z]{2}$/;
	var RegExpZip = /^[0-9]{5}$/;
	var RegExpPhone = /^[1-9]{1}[0-9]{2}$/;
	var RegExpNum = /^[1-9]{4}$/;
	var RegExpEmail = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,4})+$/;

	if (!RegExpText.test(fn))
		{
			alert("Please enter your first name");
			document.employee.efn.focus();
			document.employee.efn.select();
			document.employee.efn.style.backgroundColor = "#cccccc";
			return false;
		}

	else if(!RegExpText.test(ln))
			{
			alert("Please enter your last name");
			document.employee.eln.focus();
			document.employee.eln.select();
			document.employee.eln.style.backgroundColor = "#cccccc";
			return false;
		}
	
	else if(!RegExpAdd.test(street))
		{
			alert("Please enter your street address");
			document.employee.estreet.focus();
			document.employee.estreet.select();
			document.employee.estreet.style.backgroundColor = "#cccccc";
			return false;
		}
		
	else if(!RegExpText.test(city))
		{
			alert("Please enter your city");
			document.employee.ecity.focus();
			document.employee.ecity.select();
			document.employee.ecity.style.backgroundColor = "#cccccc";
			return false;
		}
		
	else if(!RegExpST.test(st))
		{
			alert("Please enter your state");
			document.employee.estate.focus();
			document.employee.estate.select();
			document.employee.estate.style.backgroundColor = "#cccccc";
			return false;
		}
	else if(!RegExpZip.test(zip))
		{
			alert("Please enter your zip code");
			document.employee.ezip.focus();
			document.employee.ezip.select();
			document.employee.ezip.style.backgroundColor = "#cccccc";
			return false;
		}
	
	else if(!RegExpPhone.test(code))
		{
			alert("Please enter your area code");
			document.employee.code.focus();
			document.employee.code.select();
			document.employee.code.style.backgroundColor = "#cccccc";
			return false;
		}
	
	else if(!RegExpPhone.test(exch))
		{
			alert("Please enter your phone exchange");
			document.employee.exch.focus();
			document.employee.exch.select();
			document.employee.exch.style.backgroundColor = "#cccccc";
			return false;
		}
		
	else if(!RegExpNum.test(num))
		{
			alert("Please enter your phone number");
			document.employee.num.focus();
			document.employee.num.select();
			document.employee.num.style.backgroundColor = "#cccccc";
			return false;
		}
		
	else if((!RegExpEmail.test(em))&&(!RegExpEmail.test(em2)))
		{
			alert("Please enter a valid e-mail address");
			document.employee.em.focus();
			document.employee.em.select();
			document.employee.em.style.backgroundColor = "#cccccc";
			return false;
		}
	else if(em != em2)
		{
			alert("E-mail addresses do not match");
			document.employee.em.focus();
			document.employee.em.select();
			document.employee.em.style.backgroundColor = "#cccccc";
			return false;
		}

	
	else
		{
			alert("Thank you");
			makeThosecookies(eid,fn,ln,street,city,st,zip,code,exch,num,em);
			
		}	
	
	
}

var today = new Date();
var expdate = today.getTime()+(1000*60*60*24*7);

function makeThosecookies(eid,fn,ln,street,city,st,zip,code,exch,num,em){
	document.cookie="eid ="+eid+";expires="+expdate+";path=/";
	document.cookie="first_name="+fn+";expires="+expdate+";path=/";
	document.cookie="last_name="+ln+";expires="+expdate+";path=/";
	document.cookie="street="+street+";expires="+expdate+";path=/";
	document.cookie="city="+city+";expires="+expdate+";path=/";
	document.cookie="st="+st+";expires="+expdate+";path=/";
	document.cookie="zip="+zip+";expires="+expdate+";path=/";
	document.cookie="code="+code+";expires="+expdate+";path=/";
	document.cookie="exch="+exch+";expires="+expdate+";path=/";
	document.cookie="num="+num+";expires="+expdate+";path=/";
	document.cookie="em="+em+";expires="+expdate+";path=/";
}

function val_data2(){	

	var sal = document.employee2.sal.value;
	var dept = document.employee2.dept.value;
	var RegExpSal = /^[1-9]{1}[0-9]{1,7}$/;
	var RegExpDept = /^[0-9]{1,3}$/;

	if (!RegExpSal.test(sal))
		{
			alert("Please enter a salary");
			document.employee2.sal.focus();
			document.employee2.sal.select();
			document.employee2.sal.style.backgroundColor = "#cccccc";
			return false;
		}

	else if(!RegExpDept.test(dept))
			{
			alert("Please select a department");
			document.employee2.dept.focus();
			document.employee2.dept.style.backgroundColor = "#cccccc";
			return false;
		}
	else
		{
			alert("Thank you");
			makeThosecookies2(sal,dept);
			
		}
}

function makeThosecookies2(sal,dept){
	document.cookie="sal="+sal+";expires="+expdate+";path=/";
	document.cookie="dept="+dept+";expires="+expdate+";path=/";
}

function val_data3(){	
	alert("PLEASE WORK!");
	var pos = document.employee3.pos.value;
	var comm = document.employee3.comments.value;
	var empstatus = document.employee3.empstatus.value;
	alert(comm);
	alert(empstatus);
	
	var RegExpPos = /^[0-9]+$/;
	var RegExpStatus = /^[0-9]{6}$/;
	

	if (!RegExpPos.test(pos))
		{
			alert("What is the position assigned to the employee?");
			document.employee3.pos.focus();
			document.employee3.pos.style.backgroundColor = "#cccccc";
			return false;
		}
	else if (comm == "")
		{
			alert("Please provide comments about the employee status.");
			document.employee3.comments.focus();
			document.employee3.comments.select();
			document.employee3.comments.style.backgroundColor = "#cccccc";
			return false;
		}
	else if (empstatus == "")
		{
			alert("What is the employee status?");
			document.employee3.comments.focus();
			document.employee3.comments.select();
			document.employee3.comments.style.backgroundColor = "#cccccc";
			return false;
		}
	else
		{
			alert("Thank you");
			makeThosecookies3(pos,comm,empstatus);
			
		}
}

function makeThosecookies3(pos,comm,empstatus){
	document.cookie="pos="+pos+";expires="+expdate+";path=/";
	document.cookie="comm="+comm+";expires="+expdate+";path=/";
	document.cookie="estat="+empstatus+";expires="+expdate+";path=/";
}
