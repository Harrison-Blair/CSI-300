// JavaScript Document to validate employee updates

function update_data(){	
var check = document.update.check.value;
if(check == 1)
{
	var eid = document.update.eid.value;
	var street = document.update.estreet.value;
	var city = document.update.ecity.value;
	var st = document.update.estate.value.toUpperCase();
	var zip = document.update.ezip.value;
	
	var RegExpID = /^([1][0-9]+)|([1-9]\d*)$/;
	var RegExpText = /^[A-Z a-z]+$/;
	var RegExpAdd = /^[A-Z a-z 0-9]+$/;
	var RegExpST = /^[A-Za-z]{2}$/;
	var RegExpZip = /^[0-9]{5}$/;
	
	if(!RegExpID.test(eid))
		{
			alert("There was an issue transmitting data. Please start agin.");
			return false;
		}
	else if(!RegExpAdd.test(street))
		{
			alert("Please enter the street address");
			document.update.estreet.focus();
			document.update.estreet.select();
			document.update.estreet.style.backgroundColor = "#cccccc";
			return false;
		}
		
	else if(!RegExpText.test(city))
		{
			alert("Please enter a city");
			document.update.ecity.focus();
			document.update.ecity.select();
			document.update.ecity.style.backgroundColor = "#cccccc";
			return false;
		}
		
	else if(!RegExpST.test(st))
		{
			alert("Please enter a state");
			document.update.estate.focus();
			document.update.estate.select();
			document.update.estate.style.backgroundColor = "#cccccc";
			return false;
		}
	else if(!RegExpZip.test(zip))
		{
			alert("Please enter a zip code");
			document.update.ezip.focus();
			document.update.ezip.select();
			document.update.ezip.style.backgroundColor = "#cccccc";
			return false;
		}
	
	else
		{
			alert("Thank you");
			return true;
		}	
	
	
}
else if(check == 2)
{
	var eid = document.update.eid.value;
	var posid = document.update.posid.value;
	var new_sal = document.update.new_sal.value;
	var stat = document.update.stat.value;
	
	var RegExpID = /^([1][0-9]+)|([1-9]\d*)$/;
	
	if(!RegExpID.test(eid))
		{
			alert("There was an issue transmitting data. Please start again.");
			return false;
		}
	if(!RegExpID.test(posid))
		{
			alert("Please select a position.");
			return false;
		}
		
	else if(!RegExpID.test(new_sal))
		{
			alert("Please enter a salary.");
			document.update.new_sal.focus();
			document.update.new_sal.select();
			document.update.new_sal.style.backgroundColor = "#cccccc";
			return false;
		}
		
	else if(!RegExpID.test(stat))
		{
			alert("Please select a reason for the update.");
			return false;
		}
		
	else
		{
			alert("Thank you");
			return true;
		}	
	
	
}
else
{
	alert("We cannot process your request.");
}

}
