// JavaScript Document
	
function findCookie(val) {
    var cookie = null;
    var findVal = val + "=";
    var dc = document.cookie;
    if (dc.length > 0)
    {
       var start = dc.indexOf(findVal);
       if (start >= 0)
       {
          start += findVal.length;
          lastVal = dc.indexOf(";", start);
          if (lastVal == -1)
          {
             lastVal = dc.length;
          }
          cookie = (dc.substring(start, lastVal));
          }
          else
          {
             return cookie;
          }
        }
		return cookie;		
}

var fname=findCookie("first_name");
var lname=findCookie("last_name");
var addr = findCookie("address");
var em = findCookie("email");
var sys = findCookie("sys");
var course = findCookie("course");
var yr = findCookie("year");
var comm = findCookie("comments");
var word = findCookie("apps0");
var excel = findCookie("apps1");
var ppt = findCookie("apps2");

var labels = new Array("First Name","Last Name","Address","E-Mail Address","Operating System","Course","Year in School","Comments");
var cookieArray = new Array(fname,lname,addr,em,sys,course,yr,comm);


function showCookies(){
	document.write("<table id='tableTitle'><tr><td colspan='2'>Form Confirmation Page");
	document.write("</td></tr>");
	document.write("<tr><td colspan='2' id='intro'><h3>Please confirm your input is correct. ");
	document.write("If you need to make any changes, please click on the 'Return to Form' button below.");
	document.write("</h3></td></tr>");
	
	for (i=0;i<5;i++)
		{
			document.write("<tr><td class='labels'>");
			document.write(labels[i]+": </td><td class='data'>");
			document.write(cookieArray[i]);
			document.write("</td></tr>");
		}
				
	document.write("<tr><td class='labels'>Applications:</td><td class='data'>");
		appsDisplayCookies();
	document.write("</td></tr>");

	for(i=5;i<labels.length;i++)
		{
			document.write("<tr><td class='labels'>");
			document.write(labels[i]+": </td><td class='data'>");
			document.write(cookieArray[i]);
			document.write("</td></tr>");
		}			

	}
	
function appsDisplayCookies(){

	var appCookie = new Array(word,excel,ppt);
	for (i=0;i<appCookie.length;i++)
		{
			if((appCookie[i] !="")&&(appCookie[i] !=null))
				{
					document.write(appCookie[i]+"<br>");
				}
		}
}















