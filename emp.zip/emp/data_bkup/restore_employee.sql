CREATE DATABASE  IF NOT EXISTS `employees` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `employees`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: employees
-- ------------------------------------------------------
-- Server version	5.7.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `eaid` int(11) NOT NULL,
  `estreet` varchar(30) NOT NULL,
  `ecity` varchar(30) NOT NULL,
  `estate` char(2) NOT NULL,
  `ezip` char(5) NOT NULL,
  `eid` int(11) NOT NULL,
  PRIMARY KEY (`eaid`),
  KEY `fk_Address_Employee1` (`eid`),
  CONSTRAINT `fk_Address_Employee1` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'110 Main Street','Winooski','VT','05404',1),(2,'10 South Evan Road','Manchester','NH','03101',2),(3,'25 North Avenue','Rome','NY','13440',3),(4,'9875 East West Street','Providence','RI','02901',4),(5,'23 Los Alomos Road','Bangor','ME','04401',5),(6,'99 Brilliant Road','Montpelier','VT','05602',6),(7,'14 Highpoint Avenue','Albany','NY','12335',7),(8,'89-48 East 72nd Street','New York City','NY','10118',8),(9,'100 Unknown Drive','Lesserknown','NH','03456',9),(10,'987 Forward Avenue','Augusta','ME','04330',10),(11,'12 Lane Road','Colchester','VT','05439',11),(12,'17 Fordham Place','Hempstead','NY','11550',12),(13,'10 East willard street','Burlington','VT','05401',13),(15,'16 South Union Road','Halifax','MA','02338',15),(21,'23 Whats My Age Again Rd','Johnson','VT','05439',21),(27,'22 Fish Lane','Atlanta','GA','02345',27),(28,'1964 Disney Road','Orlando','FL','68429',28),(29,'60 Hall Road','East City','CT','21660',29),(30,'47 Known Ave','West Land','AK','93640',30),(31,'12 Ride Road','Hemmingsburg','UK','00123',31),(32,'1 Candy Lane','Sugar','WY','71943',32),(48,'3392 US Route 5','Westminster','VT','05158',48),(49,'22 Cortland Place','Oxford','CT','06478',49),(50,'1 College Avenue','Factoryville','PA','18419',50),(51,'1 Tesla Street','East Shoreham','NY','11786',51),(52,'1531 Western Avenue','Seattle','WA','98101',52),(58,'25 South Road','Middletown','VA','15896',58),(59,'156 Fall Drive','Freewell','WA','08964',59),(60,'258 Chanler Street','Arrow','NY','06874',60),(61,'50 Rose Drive','Hartford','CT','06895',61),(62,'7888 Fort Drive','Worthfield','VA','07854',62),(63,'23 Pants Rd','Boston','MA','04424',63),(64,'21 Year Old Drive','WhereDoomed','NJ','08888',64),(65,'666 Rocky Rd','DownUnder','HI','11100',65),(66,'1 Presidents Lane','Mount Vernon','VA','56897',66),(67,'509 Woods Hollow Road','Westford','VT','05494',67),(69,'75 SpiderMan Lane','Anothercity','CT','78459',69),(70,'987 Super Man Street','Augusta','ME','04330',70),(71,'1 Stark Towers','New York City','NY','10118',71),(72,'6 Feet Under','Nowhere','NY','11550',72),(73,'12 Clean Street','Madison','NY','12050',73),(74,'9 Turcotte Street','Attleboro','MA','02703',74),(75,'29 Beagle Club Road','Attleboro','MA','02703',75),(76,'13 Greenfield Street','Attleboro','MA','02703',76),(77,'2954 Pullen Ave','Fall River','MA','02720',77),(78,'56 Llama Road','Bangor','ME','04401',78),(79,'46 Somewhere St.','Bobsled','AZ','78956',79),(80,'7 Goneware Dr.','Acktid','MA','58792',80),(81,'18 Zelwa Place','Yelon','TX','22356',81),(82,'2 Beltham Boulevard','Taigrex','CA','33659',82),(83,'37 Faylon Dr.','Einsworth','AK','11550',83),(84,'38 South Main Street','North Brookfield','MA','01535',84),(85,'1 Pond Lane','Charlton','MA','04566',85),(86,'146 East Northeast Avenue','Topeka','KS','89562',86),(87,'987 Windy Drive','Santa Monica','CA','98960',87),(88,'4592 Drive Way','Orlando','FL','78523',88),(89,'182 Brook Hill Lane','Vernon Hills','IL','60061',89),(90,'103 Southern Street','Winooski','VT','05404',90),(91,'102 Cushman Street','Waterbury','CT','06704',91),(92,'120 Vista Street','San Antonio','TX','78213',92),(93,'186 Devoe Avenue','Yonkers','NY','10705',93),(94,'7 South Evan Road','Dover','NH','03820',94),(95,'5 Linda Avenue','Portsmouth','NH','03801',95),(96,'246 Soper Point Road','Old Forge','NY','13420',96),(97,'32 Cranbrooke Drive','Rochester','NY','13620',97),(98,'1 Risky Business Avenue','Here','VT','05489',98),(99,'2938 River Rd.','Schennectady','NY','13264',99),(100,'10 East willard street','Burlington','VT','05401',100),(101,'23 South Winner Road','Enosburg Falls','VT','05450',101),(102,'16 South Union Road','Halifax','MA','02338',102),(103,'8 North Genius Road','Plymouth','MA','02334',103),(104,'88 North Ovitt Road','Lisbon','NH','03101',104),(105,'123 Fake St.','Faketown','VT','05101',105),(106,'25 Winooski Falls Way','Winooski','VT','05404',106),(107,'326 Quarry Hill Dr.','S. Burlington','VT','05404',107),(108,'404 Notfound St.','Nowhere','VT','05404',108),(109,'1 mySt.','myTown','VT','11111',109),(110,'111 Main Street','Winooski','VT','05404',110),(111,'11 South Evan Road','Manchester','NH','03101',111),(112,'26 North Avenue','Rome','NY','13440',112),(113,'985 East West Street','Providence','RI','02901',113),(114,'265743214 Los Alomos Road','Bangor','ME','04401',114),(115,'42 Main Street','Worcester','MA','01601',115),(116,'1 Buck Street','Durham','NH','03824',116),(117,'30 Hayward Steet','Burlington','VT','05401',117),(118,'5 Cambell Court','Dover','NH','03820',118),(119,'32 Post Road','Bangor','ME','04401',119),(120,'64 Road Rage Lane','Wikita','VT','05859',120),(121,'999 NinteyNineNine','Bubbletown','VT','05205',121),(122,'One','Two','VT','05952',122),(123,'40 Wowzer drive','Hineburg','VT','05505',123),(124,'222 Megatown','Megaville','VT','05892',124),(125,'12 Galaxy Faraway','Outerspace','NY','05403',125),(126,'1 Middle Road','South Burlington','VT','21350',126),(127,'1 Trump Plaza','New York','NY','11550',127),(128,'777 Heaven Place','Heaven','NY','77777',128),(129,'19083 Park Place','Monopoly','AK','45650',129),(130,'14 Round Circle','Utica','NY','12843',130),(131,'123 Fake Street','Burlington','MA','02348',131),(132,'90 Central Street','Natick','MA','01760',132),(133,'65 Pond Road','Bath','ME','65875',133),(134,'67 Lake Street','Portland','NH','12354',134),(135,'450 College Street','Burlington','VT','05401',135),(136,'14 South Pole Dr','North Pole','ND','05404',136),(137,'89 Dogwood Dr','Townshend','VT','05114',137),(138,'163 South Willard Street','Burlington','VT','05401',138),(139,'69 Groovy Way','Funky Town','CA','44206',139),(140,'65 South Union','Burlington','VT','05401',140),(141,'1 Wayne Manor Road','Gotham City','NY','10118',141),(142,'1 Amazonian trail','Amazon','VT','05401',142),(143,'25 Not Superman\'s house Road ','Metropolis','CA','11550',143),(144,'20 Ingram Street','Queens','NY','11428',144),(145,'4 Super Villain Road ','Gotham City','NY','11550',145),(146,'20 West Canal Street','Winooski','VT','05404',146),(147,'17 Andy Avenue','Swanton','VT','05488',147),(148,'154 Short Street','Highgate','VT','05459',148),(149,'303 South Street','Multivast','TX','03784',149),(150,'10 Main Street','Saint Albans','VT','05478',150),(151,'13 Dogwood Drive','East Hampton','CT','06424',151),(152,'2 Harlem Place','Atlanta','GA','25764',152),(153,'1 Sesame Street','Cooperstown','NY','11550',153),(154,'312 North James Road','Alabaster','CT','06453',154),(155,'568 East Varsity Street','Albany','NY','13440',155),(156,'10284 West Advantage Avenue','Northport','CA','05832',156),(157,'745 Falcon Way Road','Portland','WA','68440',157),(158,'496 Leftwing Circle','Cheshire','CT','06428',158),(159,'17 Coll Lane','Nowhere','KY','03342',159),(160,'20 Cherry Street','Providence','RI','02901',160),(161,'47 Celtics Ave','Boston','MA','79631',161),(162,'49 Hoyle Street','Norwood','MA','02062',162);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER duplicateAddCheck BEFORE INSERT ON Address
  FOR EACH ROW BEGIN
    DECLARE matchingAdds INTEGER;
   
    SELECT COUNT(*) INTO matchingAdds
        FROM Address
        WHERE    
            NEW.estreet = estreet AND
			NEW.ecity = ecity AND
			NEW.estate = estate AND
			NEW.ezip = ezip;
           
    IF matchingAdds > 0 THEN
		INSERT INTO ErrorAddressLog VALUES (NEW.eid,NEW.eaid,"Address", NOW(), CONCAT("Duplicate Address: ",NEW.estreet,'  ',NEW.ecity,', ',NEW.estate,'  ',NEW.ezip));
    END IF;

  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `contact`
--

DROP TABLE IF EXISTS `contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contact` (
  `eid` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  `contact` varchar(45) NOT NULL,
  PRIMARY KEY (`eid`,`contact_id`),
  KEY `fk_Contact_ContactType1` (`contact_id`),
  CONSTRAINT `fk_Contact_ContactType1` FOREIGN KEY (`contact_id`) REFERENCES `contacttype` (`contact_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_Contact_Employee1` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact`
--

LOCK TABLES `contact` WRITE;
/*!40000 ALTER TABLE `contact` DISABLE KEYS */;
INSERT INTO `contact` VALUES (1,1,'802-365-8678'),(1,2,'BruceJones01@neb.com'),(2,1,'802-365-3449'),(2,2,'WendySmith@neb.com'),(3,1,'802-365-8546'),(3,2,'WilliamPenn@neb.com'),(4,1,'802-365-4054'),(4,2,'JoanArc@neb.com'),(5,1,'802-365-7644'),(5,2,'AlbertEinstein@neb.com'),(6,1,'802-365-9520'),(6,2,'MarieCurrie@neb.com'),(7,1,'802-365-7883'),(7,2,'MargaretThatcher@neb.com'),(8,1,'802-365-5899'),(8,2,'John D.Manchester@neb.com'),(9,1,'802-365-3755'),(9,2,'JohnDoe@neb.com'),(10,1,'802-365-8303'),(10,2,'JaneSame@neb.com'),(11,1,'802-365-2080'),(11,2,'TomSmythe@neb.com'),(12,1,'802-365-3156'),(12,2,'KateAbbott@neb.com'),(13,1,'802-365-5586'),(13,2,'BethuneEmily@neb.com'),(15,1,'802-365-7363'),(15,2,'FlowerDaisy@neb.com'),(21,1,'802-365-6143'),(21,2,'LilySnyder@neb.com'),(27,1,'802-365-3578'),(27,2,'SteveScuba@neb.com'),(28,1,'802-365-7496'),(28,2,'MickeyMouse@neb.com'),(29,1,'802-365-3620'),(29,2,'ChrisJones@neb.com'),(30,1,'802-365-4212'),(30,2,'MacLeMore@neb.com'),(31,1,'802-365-9717'),(31,2,'DagNabbit@neb.com'),(32,1,'802-365-7829'),(32,2,'WilliamWonka@neb.com'),(48,1,'802-365-5725'),(48,2,'GarthFitzgerald@neb.com'),(49,1,'802-365-7377'),(49,2,'BarbaraMartin@neb.com'),(50,1,'802-365-3872'),(50,2,'HomerReynolds@neb.com'),(51,1,'802-365-1671'),(51,2,'NikolaTesla@neb.com'),(52,1,'802-365-6660'),(52,2,'SebastianAlias@neb.com'),(58,1,'802-365-6369'),(58,2,'JohnBrown01@neb.com'),(59,1,'802-365-2592'),(59,2,'PeterWhite@neb.com'),(60,1,'802-365-1449'),(60,2,'JoshGreen@neb.com'),(61,1,'802-365-3168'),(61,2,'JoanJacobs@neb.com'),(62,1,'802-365-6775'),(62,2,'JenniferAtrast@neb.com'),(63,1,'802-365-4478'),(63,2,'TaylorBigam@neb.com'),(64,1,'802-365-2915'),(64,2,'DudleeDudders@neb.com'),(65,1,'802-365-5111'),(65,2,'FosterDood@neb.com'),(66,1,'802-365-2989'),(66,2,'GeorgeWashington@neb.com'),(67,1,'802-365-7928'),(67,2,'KatKillinger@neb.com'),(69,1,'802-365-5204'),(69,2,'PeterParker01@neb.com'),(70,1,'802-365-3421'),(70,2,'ClarkKent01@neb.com'),(71,1,'802-365-1401'),(71,2,'TonyStark@neb.com'),(72,1,'802-365-4286'),(72,2,'AgentCoulson@neb.com'),(73,1,'802-365-4409'),(73,2,'OscarMadison@neb.com'),(74,1,'802-365-2079'),(74,2,'BrianneDeVincent@neb.com'),(75,1,'802-365-2361'),(75,2,'RichardTeabeau@neb.com'),(76,1,'802-365-2790'),(76,2,'WilliamReynolds@neb.com'),(77,1,'802-365-8194'),(77,2,'KennedyTran@neb.com'),(78,1,'802-365-7372'),(78,2,'AlmaConway@neb.com'),(79,1,'802-365-2976'),(79,2,'JamesHujjiba@neb.com'),(80,1,'802-365-6329'),(80,2,'KileAggot@neb.com'),(81,1,'802-365-5971'),(81,2,'HeirichWanger@neb.com'),(82,1,'802-365-9375'),(82,2,'ZenAntonitii@neb.com'),(83,1,'802-365-4508'),(83,2,'TialaSumardar@neb.com'),(84,1,'802-365-4613'),(84,2,'DavidJones@neb.com'),(85,1,'802-365-4705'),(85,2,'SantaClaws@neb.com'),(86,1,'802-365-4478'),(86,2,'JohnnyRocket@neb.com'),(87,1,'802-365-9859'),(87,2,'RachaelHunter@neb.com'),(88,1,'802-365-3574'),(88,2,'EasterBunny@neb.com'),(89,1,'802-365-7603'),(89,2,'TimothySmith@neb.com'),(90,1,'802-365-7657'),(90,2,'FranklinArts@neb.com'),(91,1,'802-365-5226'),(91,2,'AnnaCaisse@neb.com'),(92,1,'802-365-9988'),(92,2,'EricOlivares@neb.com'),(93,1,'802-365-4782'),(93,2,'ThomasSampson@neb.com'),(94,1,'802-365-8164'),(94,2,'JasonJohn@neb.com'),(95,1,'802-365-4450'),(95,2,'TomJane@neb.com'),(96,1,'802-365-6888'),(96,2,'BillyVale@neb.com'),(97,1,'802-365-9203'),(97,2,'JoeyLaskowski@neb.com'),(98,1,'802-365-4425'),(98,2,'YourName@neb.com'),(99,1,'802-365-2339'),(99,2,'LukeColletti@neb.com'),(100,1,'802-365-8093'),(100,2,'EmilyBethune@neb.com'),(101,1,'802-365-3066'),(101,2,'JoanneOvitt@neb.com'),(102,1,'802-365-5707'),(102,2,'DaisyFlower@neb.com'),(103,1,'802-365-5386'),(103,2,'DumbDumber@neb.com'),(104,1,'802-365-8055'),(104,2,'SamanthaOvitt@neb.com'),(105,1,'802-365-3492'),(105,2,'FakeyMcPhoney@neb.com'),(106,1,'802-365-8086'),(106,2,'JohnMongler@neb.com'),(107,1,'802-365-9894'),(107,2,'DudeMcBro@neb.com'),(108,1,'802-365-4639'),(108,2,'NullyValue@neb.com'),(109,1,'802-365-4917'),(109,2,'JohnSmith@neb.com'),(110,1,'802-365-1248'),(110,2,'FrankTank@neb.com'),(111,1,'802-365-3966'),(111,2,'RobBob@neb.com'),(112,1,'802-365-8939'),(112,2,'SpongeBob@neb.com'),(113,1,'802-365-3002'),(113,2,'TitoSummers@neb.com'),(114,1,'802-365-8850'),(114,2,'BoMessier@neb.com'),(115,1,'802-365-5141'),(115,2,'BobCross@neb.com'),(116,1,'802-365-6484'),(116,2,'WillSamuel@neb.com'),(117,1,'802-365-6740'),(117,2,'JohnEvans@neb.com'),(118,1,'802-365-5069'),(118,2,'MichelleMichael@neb.com'),(119,1,'802-365-1553'),(119,2,'JuanSucro@neb.com'),(120,1,'802-365-8585'),(120,2,'JonathanLobe@neb.com'),(121,1,'802-365-6272'),(121,2,'JimmyJam@neb.com'),(122,1,'802-365-6233'),(122,2,'OnetwoTwoone@neb.com'),(123,1,'802-365-9969'),(123,2,'AbeLincoln@neb.com'),(124,1,'802-365-9848'),(124,2,'MegaMan@neb.com'),(125,1,'802-365-2733'),(125,2,'LukeSkywalker@neb.com'),(126,1,'802-365-2548'),(126,2,'RoadKill@neb.com'),(127,1,'802-365-1785'),(127,2,'DerekJeter@neb.com'),(128,1,'802-365-5183'),(128,2,'MyWonder@neb.com'),(129,1,'802-365-1941'),(129,2,'PassGo@neb.com'),(130,1,'802-365-3631'),(130,2,'PeterPeterson@neb.com'),(131,1,'802-365-3993'),(131,2,'JamieJamieson@neb.com'),(132,1,'802-365-8569'),(132,2,'JordanBerkowitz@neb.com'),(133,1,'802-365-3021'),(133,2,'JohnBrown02@neb.com'),(134,1,'802-365-9545'),(134,2,'JessicaJacket@neb.com'),(135,1,'802-365-8074'),(135,2,'JakeJohnson@neb.com'),(136,1,'802-365-1710'),(136,2,'SantaClause@neb.com'),(137,1,'802-365-8040'),(137,2,'BruceJones@neb.com'),(138,1,'802-365-9914'),(138,2,'FrankCanovatchel@neb.com'),(139,1,'802-365-2304'),(139,2,'GuyGetdown@neb.com'),(140,1,'802-365-5498'),(140,2,'SungFugong@neb.com'),(141,1,'802-365-2304'),(141,2,'BruceWayne@neb.com'),(142,1,'802-365-8308'),(142,2,'WonderWoman@neb.com'),(143,1,'802-365-8741'),(143,2,'ClarkKent02@neb.com'),(144,1,'802-365-5344'),(144,2,'PeterParker02@neb.com'),(145,1,'802-365-6692'),(145,2,'MisterFreeze@neb.com'),(146,1,'802-365-8339'),(146,2,'BarryWhite@neb.com'),(147,1,'802-365-7334'),(147,2,'JeffSeid@neb.com'),(148,1,'802-365-6946'),(148,2,'MarkWahlberg@neb.com'),(149,1,'802-365-8964'),(149,2,'JamesBoiben@neb.com'),(150,1,'802-365-9756'),(150,2,'AzizShavershain@neb.com'),(151,1,'802-365-6213'),(151,2,'HenryQuinn@neb.com'),(152,1,'802-365-9713'),(152,2,'RickGrimes@neb.com'),(153,1,'802-365-7993'),(153,2,'BigBird@neb.com'),(154,1,'802-365-9874'),(154,2,'SallyJane@neb.com'),(155,1,'802-365-9268'),(155,2,'AmandaFintz@neb.com'),(156,1,'802-365-4735'),(156,2,'MarcBartalone@neb.com'),(157,1,'802-365-1577'),(157,2,'BrianParker@neb.com'),(158,1,'802-365-7989'),(158,2,'SteveBates@neb.com'),(159,1,'802-365-8109'),(159,2,'WallacePenguin@neb.com'),(160,1,'802-365-3074'),(160,2,'JackDaniels@neb.com'),(161,1,'802-365-4051'),(161,2,'AnthonyLarosa@neb.com'),(162,1,'802-365-7455'),(162,2,'HubertBowtie@neb.com');
/*!40000 ALTER TABLE `contact` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER duplicateContactCheck BEFORE INSERT ON Contact
  FOR EACH ROW BEGIN
    DECLARE matchingContact INTEGER;
   
    SELECT COUNT(*) INTO matchingContact
        FROM Contact
        WHERE    
            NEW.contact_id = contact_id AND
            NEW.contact = contact;
           
    IF matchingContact > 0 THEN
			INSERT INTO ErrorContactLog VALUES (NEW.eid,NEW.contact_id,"Contact", NOW(), concat(NEW.eid,' ',NEW.contact_id,' ',NEW.contact));
    END IF;

  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `contacttype`
--

DROP TABLE IF EXISTS `contacttype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacttype` (
  `contact_id` int(11) NOT NULL,
  `contact_desc` varchar(45) NOT NULL,
  PRIMARY KEY (`contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacttype`
--

LOCK TABLES `contacttype` WRITE;
/*!40000 ALTER TABLE `contacttype` DISABLE KEYS */;
INSERT INTO `contacttype` VALUES (1,'Office Phone'),(2,'Company E-Mail Address'),(3,'Other Contact Information');
/*!40000 ALTER TABLE `contacttype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `dept_id` int(11) NOT NULL,
  `dept_name` varchar(45) NOT NULL,
  PRIMARY KEY (`dept_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (1,'Sales'),(2,'Accounting'),(3,'Operations'),(4,'IT'),(5,'Marketing'),(6,'HR'),(7,'Management'),(8,'Facilities'),(9,'Security'),(10,'Customer Support'),(11,'Inventory Control'),(12,'Finance'),(999,'Termination');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `dup_emp_email`
--

DROP TABLE IF EXISTS `dup_emp_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dup_emp_email` (
  `eid` int(11) DEFAULT NULL,
  `efn` varchar(255) DEFAULT NULL,
  `eln` varchar(255) DEFAULT NULL,
  `estreet` varchar(255) DEFAULT NULL,
  `ecity` varchar(255) DEFAULT NULL,
  `estate` varchar(255) DEFAULT NULL,
  `ezip` varchar(255) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL,
  `count` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dup_emp_email`
--

LOCK TABLES `dup_emp_email` WRITE;
/*!40000 ALTER TABLE `dup_emp_email` DISABLE KEYS */;
INSERT INTO `dup_emp_email` VALUES (45,'Amanda','Fintz','568 East Varsity Street','Albany','NY','13440','AmandaFintz@neb.com',2),(40,'Anna','Caisse','102 Cushman Street','Waterbury','CT','06704','AnnaCaisse@neb.com',2),(47,'Brian','Parker','745 Falcon Way Road','Portland','WA','68440','BrianParker@neb.com',2),(55,'Bruce','Jones','89 Dogwood Dr','Townshend','VT','05114','BruceJones@neb.com',2),(68,'Bruce','Wayne','1 Wayne Manor Road','Gotham City','NY','10118','BruceWayne@neb.com',2),(33,'David','Jones','38 South Main Street','North Brookfield','MA','01535','DavidJones@neb.com',2),(25,'Derek','Jeter','1 Trump Plaza','New York','NY','11550','DerekJeter@neb.com',2),(19,'Dudlee','Dudders','21 Year Old Drive','WhereDoomed','NJ','08888','DudleeDudders@neb.com',2),(16,'Dumb','Dumber','8 North Genius Road','Plymouth','MA','02334','DumbDumber@neb.com',2),(37,'Easter','Bunny','4592 Drive Way','Orlando','FL','78523','EasterBunny@neb.com',2),(41,'Eric','Olivares','120 Vista Street','San Antonio','TX','78213','EricOlivares@neb.com',2),(20,'Foster','Dood','666 Rocky Rd','DownUnder','HI','11100','FosterDood@neb.com',2),(39,'Franklin','Arts','103 Southern Street','Winooski','VT','05404','FranklinArts@neb.com',2),(56,'Guy','Getdown','69 Groovy Way','Funky Town','CA','44206','GuyGetdown@neb.com',2),(53,'Jake','Johnson','450 College Street','Burlington','VT','05401','JakeJohnson@neb.com',2),(43,'James','Boiben','303 South Street','Multivast','TX','03784','JamesBoiben@neb.com',2),(14,'Joanne','Ovitt','23 South Winner Road','Enosburg Falls','VT','05450','JoanneOvitt@neb.com',2),(35,'Johnny','Rocket','146 East Northeast Avenue','Topeka','KS','89562','JohnnyRocket@neb.com',2),(22,'Kat','Killinger','509 Woods Hollow Road','Westford','VT','05494','KatKillinger@neb.com',2),(23,'Luke','Skywalker','12 Galaxy Faraway','Outerspace','NY','05403','LukeSkywalker@neb.com',2),(46,'Marc','Bartalone','10284 West Advantage Avenue','Northport','CA','05832','MarcBartalone@neb.com',2),(26,'Pass','Go','19083 Park Place','Monopoly','AK','45650','PassGo@neb.com',2),(36,'Rachael','Hunter','987 Windy Drive','Santa Monica','CA','98960','RachaelHunter@neb.com',2),(24,'Road','Kill','1 Middle Road','South Burlington','VT','21350','RoadKill@neb.com',2),(44,'Sally','Jane','312 North James Road','Alabaster','CT','06453','SallyJane@neb.com',2),(17,'Samantha','Ovitt','88 North Ovitt Road','Lisbon','NH','03101','SamanthaOvitt@neb.com',2),(54,'Santa','Clause','14 South Pole Dr','North Pole','ND','05404','SantaClause@neb.com',2),(34,'Santa','Claws','1 Pond Lane','Charlton','MA','04566','SantaClaws@neb.com',2),(57,'Sung','Fugong','65 South Union','Burlington','VT','05401','SungFugong@neb.com',2),(18,'Taylor','Bigam','23 Pants Rd','Boston','MA','04424','TaylorBigam@neb.com',2),(42,'Thomas','Sampson','186 Devoe Avenue','Yonkers','NY','10705','ThomasSampson@neb.com',2),(38,'Timothy','Smith','182 Brook Hill Lane','Vernon Hills','IL','60061','TimothySmith@neb.com',2);
/*!40000 ALTER TABLE `dup_emp_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `emp_add`
--

DROP TABLE IF EXISTS `emp_add`;
/*!50001 DROP VIEW IF EXISTS `emp_add`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `emp_add` AS SELECT 
 1 AS `eid`,
 1 AS `efn`,
 1 AS `eln`,
 1 AS `estreet`,
 1 AS `ecity`,
 1 AS `estate`,
 1 AS `ezip`,
 1 AS `salary`,
 1 AS `pos_name`,
 1 AS `dept_name`,
 1 AS `contact`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `emphistory`
--

DROP TABLE IF EXISTS `emphistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emphistory` (
  `eid` int(11) NOT NULL,
  `pos_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `start_salary` int(6) NOT NULL,
  `status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`eid`,`pos_id`,`start_date`),
  KEY `fk_EmpHistory_Status1` (`status_id`),
  CONSTRAINT `fk_EmpHistory_EmployeePosition1` FOREIGN KEY (`eid`, `pos_id`) REFERENCES `employeeposition` (`eid`, `pos_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_EmpHistory_Status1` FOREIGN KEY (`status_id`) REFERENCES `historystatus` (`status_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emphistory`
--

LOCK TABLES `emphistory` WRITE;
/*!40000 ALTER TABLE `emphistory` DISABLE KEYS */;
INSERT INTO `emphistory` VALUES (1,1,'2005-11-19',45000,999999),(2,1,'2003-07-26',45000,999999),(3,2,'2007-02-03',45000,1),(4,2,'2004-04-30',45000,1),(5,3,'2013-03-25',45000,1),(6,3,'2008-07-26',45000,1),(7,4,'2003-09-19',45000,1),(8,4,'2002-04-24',45000,1),(9,5,'2015-08-30',45000,999999),(10,5,'2015-11-27',45000,999999),(11,6,'2002-11-10',45000,1),(12,6,'2015-02-11',45000,1),(13,7,'2005-08-16',45000,1),(15,8,'2009-07-10',45000,1),(21,9,'2010-06-27',43000,999999),(27,66,'2015-02-27',45000,1),(28,49,'2002-10-29',30000,999999),(29,55,'2004-12-06',55000,1),(30,39,'2007-11-23',80000,1),(31,57,'2006-01-12',75000,1),(32,24,'2002-07-15',110000,1),(48,10,'2011-03-04',45000,1),(49,26,'2014-03-03',45000,1),(50,28,'2002-10-03',45000,1),(51,34,'2001-05-05',45000,1),(52,18,'2003-10-29',45000,1),(58,1,'2017-08-18',45000,999999),(59,2,'2003-02-20',65000,1),(60,3,'2005-01-19',35000,1),(61,4,'2013-10-15',65000,1),(62,5,'2009-03-11',35000,999999),(63,4,'2011-01-12',65000,1),(64,11,'2002-07-23',55000,1),(65,9,'2004-04-29',35000,999999),(66,2,'2010-10-12',70000,1),(67,5,'2009-11-04',45000,999999),(69,22,'2018-02-02',55000,1),(70,48,'2003-04-17',55000,1),(71,57,'2007-10-23',55000,1),(72,6,'2011-01-30',35000,1),(73,9,'2005-05-23',80000,999999),(74,24,'2008-05-25',72000,1),(75,17,'2015-07-20',82143,1),(76,51,'2006-09-13',20000,1),(77,54,'2003-08-16',76000,1),(78,5,'2010-10-14',65000,999999),(79,5,'2009-05-08',40000,999999),(80,6,'2010-08-20',66000,1),(81,6,'2006-07-26',62000,1),(82,6,'2018-04-25',61000,1),(83,8,'2015-08-04',46000,1),(84,2,'2001-11-09',32000,1),(85,6,'2005-09-13',44000,1),(86,10,'2009-12-15',45000,1),(87,12,'2004-12-21',38000,1),(88,9,'2004-10-11',68000,999999),(89,5,'2009-03-02',450000,1),(90,4,'2006-03-29',490000,1),(91,8,'2016-07-25',9999999,1),(92,8,'2006-04-29',120000,1),(93,7,'2012-08-21',42075,1),(94,6,'2014-09-06',42100,1),(95,5,'2014-11-26',42125,999999),(96,4,'2017-11-25',42150,1),(97,3,'2017-04-13',42175,1),(98,29,'2016-10-26',46500,999999),(99,49,'2016-01-06',22000,999999),(100,42,'2005-07-29',37000,1),(101,21,'2005-04-21',51000,1),(102,9,'2014-04-24',77000,999999),(103,16,'2010-09-27',115000,1),(104,17,'2012-03-09',80000,1),(105,18,'2007-12-28',83000,1),(106,19,'2006-11-26',100000,1),(107,20,'2017-09-17',110000,1),(108,29,'2014-11-16',50000,999999),(109,41,'2012-03-23',35000,999999),(110,44,'2008-08-17',65000,1),(111,30,'2015-11-15',55000,1),(112,51,'2015-05-01',45000,1),(113,1,'2007-05-06',50000,999999),(114,2,'2013-08-08',60000,1),(115,3,'2002-10-09',100000,1),(116,4,'2009-03-20',55000,1),(117,5,'2009-09-25',75000,999999),(118,31,'2018-01-02',58000,1),(119,20,'2007-04-23',120000,1),(120,44,'2006-05-03',47000,1),(121,22,'2007-05-18',63500,1),(122,64,'2015-06-25',74000,1),(123,26,'2015-01-25',82000,1),(124,20,'2004-02-23',120000,1),(125,60,'2017-12-11',64000,1),(126,8,'2007-05-29',60000,1),(127,49,'2016-08-07',20000,999999),(128,52,'2013-07-24',45000,1),(129,61,'2008-02-29',35000,1),(130,62,'2001-05-02',25000,1),(131,54,'2011-07-03',41500,1),(132,57,'2004-02-28',49000,1),(133,52,'2012-07-01',29000,1),(134,29,'2011-11-06',40500,999999),(135,36,'2016-04-09',48000,1),(136,47,'2003-10-25',56000,1),(137,34,'2014-05-11',31000,1),(138,68,'2005-05-19',99999,1),(139,44,'2018-01-13',99999,1),(140,20,'2016-07-24',2,1),(141,52,'2015-05-01',99999,1),(142,63,'2007-02-23',16,1),(143,5,'2005-11-24',45000,999999),(144,5,'2009-10-05',45000,999999),(145,6,'2015-06-15',45000,1),(146,3,'2010-04-03',45000,1),(147,2,'2011-09-20',45000,1),(148,19,'2005-09-26',45000,1),(149,44,'2007-11-17',45000,1),(150,62,'2008-10-06',45000,1),(151,29,'2006-06-03',45000,999999),(152,26,'2017-03-28',45000,1),(153,12,'2014-07-17',30000,1),(154,5,'2007-12-30',75000,999999),(155,7,'2014-08-18',99999,1),(156,31,'2006-02-11',15000,1),(157,10,'2002-02-10',45000,1),(158,1,'2012-08-24',45000,999999),(159,2,'2014-12-25',45000,1),(160,3,'2007-01-26',45000,1),(161,4,'2015-10-16',45000,1),(162,5,'2007-01-05',45000,999999);
/*!40000 ALTER TABLE `emphistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `eid` int(11) NOT NULL,
  `efn` varchar(10) NOT NULL,
  `eln` varchar(30) NOT NULL,
  PRIMARY KEY (`eid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Bruce','Jones'),(2,'Wendy','Smith'),(3,'William','Penn'),(4,'Joan','Arc'),(5,'Albert','Einstein'),(6,'Marie','Currie'),(7,'Margaret','Thatcher'),(8,'John D.','Manchester'),(9,'John','Doe'),(10,'Jane','Same'),(11,'Tom','Smythe'),(12,'Kate','Abbott'),(13,'Bethune','Emily'),(15,'Flower','Daisy'),(21,'Lily','Snyder'),(27,'Steve','Scuba'),(28,'Mickey','Mouse'),(29,'Chris','Jones'),(30,'Mac','LeMore'),(31,'Dag','Nabbit'),(32,'William','Wonka'),(48,'Garth','Fitzgerald'),(49,'Barbara','Martin'),(50,'Homer','Reynolds'),(51,'Nikola','Tesla'),(52,'Sebastian','Alias'),(58,'John','Brown'),(59,'Peter','White'),(60,'Josh','Green'),(61,'Joan','Jacobs'),(62,'Jennifer','Atrast'),(63,'Taylor','Bigam'),(64,'Dudlee','Dudders'),(65,'Foster','Dood'),(66,'Washington','George'),(67,'Kat','Killinger'),(69,'Peter','Parker'),(70,'Clark','Kent'),(71,'Tony','Stark'),(72,'Agent','Coulson'),(73,'Oscar','Madison'),(74,'Brianne','DeVincent'),(75,'Richard','Teabeau'),(76,'William','Reynolds'),(77,'Kennedy','Tran'),(78,'Alma','Conway'),(79,'James','Hujjiba'),(80,'Kile','Aggot'),(81,'Heirich','Wagner'),(82,'Zen','Antonitii'),(83,'Tiala','Sumardar'),(84,'David','Jones'),(85,'Santa','Claws'),(86,'Johnny','Rocket'),(87,'Rachael','Hunter'),(88,'Easter','Bunny'),(89,'Timothy','Smith'),(90,'Franklin','Arts'),(91,'Anna','Caisse'),(92,'Eric','Olivares'),(93,'Thomas','Sampson'),(94,'Jason','John'),(95,'Tom','Jane'),(96,'Billy','Vale'),(97,'Joey','Laskowski'),(98,'Your','Name'),(99,'Luke','Colletti'),(100,'Emily','Bethune'),(101,'Joanne','Ovitt'),(102,'Daisy','Flower'),(103,'Dumb','Dumber'),(104,'Samantha','Ovitt'),(105,'Fakey','McPhoney'),(106,'John','Mongler'),(107,'Dude','McBro'),(108,'Nully','Value'),(109,'John','Smith'),(110,'Frank','Smith'),(111,'Rob','Bob'),(112,'Sponge','Robert'),(113,'Tito','Summers'),(114,'Bo','Messier'),(115,'Bob','Cross'),(116,'Will','Samuel'),(117,'John','Evans'),(118,'Michelle','Michaels'),(119,'Juan','Sucro'),(120,'Jonathan','Lobe'),(121,'Jimmy','Jam'),(122,'Onetwo','Twoone'),(123,'Abe','Lincoln'),(124,'Mega','Man'),(125,'Luke','Skywalker'),(126,'Road','Kill'),(127,'Derek','Jeter'),(128,'My','Wonder'),(129,'Pass','Go'),(130,'Peter','Peterson'),(131,'Jamie','Jamieson'),(132,'Jordan','Berkowitz'),(133,'John','Brown'),(134,'Jessica','Jacket'),(135,'Jake','Johnson'),(136,'Santa','Clause'),(137,'Bruce','Jones'),(138,'Frank','Canovatchel'),(139,'Guy','Getdown'),(140,'Sung','Fugong'),(141,'Bruce','Wayne'),(142,'Wonder','Woman'),(143,'Clark','Kent'),(144,'Peter','Parker'),(145,'Mister','Freeze'),(146,'Barry','White'),(147,'Jeff','Seid'),(148,'Mark','Wahlberg'),(149,'James','Boiben'),(150,'Aziz','Shavershain'),(151,'Henry','Quinn'),(152,'Rick','Grimes'),(153,'Big','Bird'),(154,'Sally','Jane'),(155,'Amanda','Fintz'),(156,'Marc','Bartalone'),(157,'Brian','Parker'),(158,'Steve','Bates'),(159,'Wallace','Penguin'),(160,'Jack','Daniels'),(161,'Anthony','Larosa'),(162,'Hubert','Bowtie');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER duplicateEmpCheck BEFORE INSERT ON Employee
  FOR EACH ROW BEGIN
    DECLARE matchingEmps INTEGER;
   
    SELECT COUNT(*) INTO matchingEmps
        FROM Employee
        WHERE    
            NEW.efn = efn AND
            NEW.eln = eln;
           
    IF matchingEmps > 0 THEN
			INSERT INTO ErrorEmployeeLog (IDValue, DBTable, DateTimeofError, ErrorDescription)
            VALUES (NEW.eid,"Employee", NOW(), CONCAT("Duplicate Full Name: ",NEW.efn," ",NEW.eln));
    END IF;

  END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `employeeposition`
--

DROP TABLE IF EXISTS `employeeposition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employeeposition` (
  `eid` int(11) NOT NULL,
  `pos_id` int(11) NOT NULL,
  `salary` int(11) NOT NULL,
  PRIMARY KEY (`eid`,`pos_id`),
  KEY `fk_EmployeePosition_Position1` (`pos_id`),
  CONSTRAINT `fk_EmployeePosition_Employee1` FOREIGN KEY (`eid`) REFERENCES `employee` (`eid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_EmployeePosition_Position1` FOREIGN KEY (`pos_id`) REFERENCES `position` (`pos_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employeeposition`
--

LOCK TABLES `employeeposition` WRITE;
/*!40000 ALTER TABLE `employeeposition` DISABLE KEYS */;
INSERT INTO `employeeposition` VALUES (1,1,40000),(2,1,40000),(3,2,45000),(4,2,45000),(5,3,45000),(6,3,45000),(7,4,55001),(8,4,55001),(9,5,40000),(10,5,40000),(11,6,45000),(12,6,45000),(13,7,45000),(15,8,55001),(21,9,75001),(27,66,64001),(28,49,30000),(29,55,85001),(30,39,60000),(31,57,74000),(32,24,75000),(48,10,80001),(49,26,75001),(50,28,85001),(51,34,40000),(52,18,80001),(58,1,40000),(59,2,45000),(60,3,45001),(61,4,65000),(62,5,35000),(63,4,65000),(64,11,85001),(65,9,75001),(66,2,45000),(67,5,40000),(69,22,55000),(70,48,55000),(71,57,64001),(72,6,35000),(73,9,80000),(74,24,72000),(75,17,82143),(76,51,20000),(77,54,76000),(78,5,40000),(79,5,40000),(80,6,45000),(81,6,45000),(82,6,45000),(83,8,55001),(84,2,35001),(85,6,44000),(86,10,80001),(87,12,90001),(88,9,75001),(89,5,40000),(90,4,65000),(91,8,65000),(92,8,65000),(93,7,45001),(94,6,42100),(95,5,40000),(96,4,55001),(97,3,45001),(98,29,46500),(99,49,22000),(100,42,37000),(101,21,51000),(102,9,77000),(103,16,115000),(104,17,80000),(105,18,83000),(106,19,100000),(107,20,110000),(108,29,50000),(109,41,35000),(110,44,50000),(111,30,55000),(112,51,30000),(113,1,40000),(114,2,45000),(115,3,55000),(116,4,55000),(117,5,40000),(118,31,58000),(119,20,120000),(120,44,47000),(121,22,63500),(122,64,74000),(123,26,82000),(124,20,120000),(125,60,64000),(126,8,60000),(127,49,20000),(128,52,30000),(129,61,64001),(130,62,64001),(131,54,75001),(132,57,64001),(133,52,29000),(134,29,40500),(135,36,48000),(136,47,56000),(137,34,31000),(138,68,600000),(139,44,50000),(140,20,100001),(141,52,30000),(142,63,64001),(143,5,40000),(144,5,40000),(145,6,45000),(146,3,45000),(147,2,45000),(148,19,95001),(149,44,45000),(150,62,64001),(151,29,45000),(152,26,75001),(153,12,90001),(154,5,40000),(155,7,55000),(156,31,50001),(157,10,80001),(158,1,40000),(159,2,45000),(160,3,45000),(161,4,55001),(162,5,40000);
/*!40000 ALTER TABLE `employeeposition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erroraddresslog`
--

DROP TABLE IF EXISTS `erroraddresslog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erroraddresslog` (
  `IDValue` int(11) DEFAULT NULL,
  `AddressID` int(11) DEFAULT NULL,
  `DBTable` varchar(100) DEFAULT NULL,
  `DateTimeofError` datetime DEFAULT NULL,
  `ErrorDescription` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erroraddresslog`
--

LOCK TABLES `erroraddresslog` WRITE;
/*!40000 ALTER TABLE `erroraddresslog` DISABLE KEYS */;
/*!40000 ALTER TABLE `erroraddresslog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `errorcontactlog`
--

DROP TABLE IF EXISTS `errorcontactlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `errorcontactlog` (
  `IDValue` int(11) DEFAULT NULL,
  `ContactID` int(11) DEFAULT NULL,
  `DBTable` varchar(100) DEFAULT NULL,
  `DateTimeofError` datetime DEFAULT NULL,
  `ErrorDescription` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `errorcontactlog`
--

LOCK TABLES `errorcontactlog` WRITE;
/*!40000 ALTER TABLE `errorcontactlog` DISABLE KEYS */;
/*!40000 ALTER TABLE `errorcontactlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `erroremployeelog`
--

DROP TABLE IF EXISTS `erroremployeelog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `erroremployeelog` (
  `IDValue` int(11) DEFAULT NULL,
  `DBTable` varchar(100) DEFAULT NULL,
  `DateTimeofError` datetime DEFAULT NULL,
  `ErrorDescription` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `erroremployeelog`
--

LOCK TABLES `erroremployeelog` WRITE;
/*!40000 ALTER TABLE `erroremployeelog` DISABLE KEYS */;
INSERT INTO `erroremployeelog` VALUES (163,'Employee','2019-04-21 18:24:49','Duplicate Full Name: Frank Canovatchel'),(163,'Employee','2019-04-21 20:07:29','Duplicate Full Name: Frank Canovatchel');
/*!40000 ALTER TABLE `erroremployeelog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `highsal`
--

DROP TABLE IF EXISTS `highsal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `highsal` (
  `eid` int(11) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `hsal` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `highsal`
--

LOCK TABLES `highsal` WRITE;
/*!40000 ALTER TABLE `highsal` DISABLE KEYS */;
INSERT INTO `highsal` VALUES (80,66000,45000),(82,61000,45000),(90,490000,65000),(158,45000,40000),(162,45000,40000),(58,45000,40000),(91,9999999,65000),(138,100000000,600000),(78,65000,40000),(115,100000,55000),(9,45000,40000),(117,75000,40000),(155,99999,55000),(66,70000,45000),(139,99999,50000),(95,42125,40000),(154,75000,40000),(1,45000,40000),(143,45000,40000),(67,45000,40000),(30,80000,60000),(114,60000,45000),(31,75000,74000),(92,120000,65000),(144,45000,40000),(112,45000,30000),(10,45000,40000),(89,450000,40000),(110,65000,50000),(2,45000,40000),(113,50000,40000),(51,45000,40000),(81,62000,45000),(141,99999,30000),(59,65000,45000),(128,45000,30000),(32,110000,75000);
/*!40000 ALTER TABLE `highsal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `historystatus`
--

DROP TABLE IF EXISTS `historystatus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `historystatus` (
  `status_id` int(11) NOT NULL,
  `status_desc` varchar(45) NOT NULL,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historystatus`
--

LOCK TABLES `historystatus` WRITE;
/*!40000 ALTER TABLE `historystatus` DISABLE KEYS */;
INSERT INTO `historystatus` VALUES (1,'Unknown'),(111111,'Promotion'),(222222,'New Hire'),(333333,'Position Terminated'),(444444,'Changed Dept.'),(555555,'Retired'),(666666,'Demoted'),(777777,'Left Company'),(888888,'Annual Raise'),(999999,'Employee Terminated');
/*!40000 ALTER TABLE `historystatus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lowsal`
--

DROP TABLE IF EXISTS `lowsal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lowsal` (
  `eid` int(11) DEFAULT NULL,
  `sal` int(11) DEFAULT NULL,
  `lsal` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lowsal`
--

LOCK TABLES `lowsal` WRITE;
/*!40000 ALTER TABLE `lowsal` DISABLE KEYS */;
INSERT INTO `lowsal` VALUES (52,45000,80000),(156,15000,50000),(132,49000,64000),(153,30000,90000),(88,68000,75000),(15,45000,55000),(65,35000,75000),(64,55000,85000),(48,45000,80000),(140,2,100000),(129,35000,64000),(60,35000,45000),(152,45000,75000),(87,38000,90000),(131,41500,75000),(29,55000,85000),(84,32000,35000),(161,45000,55000),(97,42175,45000),(8,45000,55000),(49,45000,75000),(157,45000,80000),(130,25000,64000),(50,45000,85000),(86,45000,80000),(93,42075,45000),(27,45000,64000),(150,45000,64000),(21,43000,75000),(71,55000,64000),(83,46000,55000),(7,45000,55000),(96,42150,55000),(148,45000,95000),(142,16,64000);
/*!40000 ALTER TABLE `lowsal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `position`
--

DROP TABLE IF EXISTS `position`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `position` (
  `pos_id` int(11) NOT NULL,
  `pos_name` varchar(45) NOT NULL,
  `lsal` int(11) NOT NULL,
  `hsal` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  PRIMARY KEY (`pos_id`),
  KEY `fk_Position_Department1` (`dept_id`),
  CONSTRAINT `fk_Position_Department1` FOREIGN KEY (`dept_id`) REFERENCES `department` (`dept_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `position`
--

LOCK TABLES `position` WRITE;
/*!40000 ALTER TABLE `position` DISABLE KEYS */;
INSERT INTO `position` VALUES (1,'Accountant I',30000,40000,2),(2,'Accountant II',35000,45000,2),(3,'Accountant III',45000,55000,2),(4,'Senior Accountant',55000,65000,2),(5,'Sales Rep I',30000,40000,1),(6,'Sales Rep II',35000,45000,1),(7,'Sales Rep III',45000,55000,1),(8,'Senior Sales Rep III',55000,65000,1),(9,'DB Developer I',75000,85000,4),(10,'DB Developer II',80000,90000,4),(11,'DB Developer III',85000,95000,4),(12,'Senior DB Developer',90000,100000,4),(13,'DB Administrator I',85000,95000,4),(14,'DB Administrator II',90000,100000,4),(15,'DB Administrator III',95000,105000,4),(16,'Senior DB Administrator',110000,120000,4),(17,'Network Analyst I',75000,85000,4),(18,'Network Analyst II',80000,90000,4),(19,'Network Analyst III',95000,105000,4),(20,'Senior Network Analyst',100000,120000,4),(21,'Operations Analyst I',50000,60000,3),(22,'Operations Analyst II',55000,65000,3),(23,'Operations Analyst III',60000,70000,3),(24,'Senior Operations Analyst',65000,75000,3),(25,'Marketing Analyst I',70000,80000,5),(26,'Marketing Analyst II',75000,85000,5),(27,'Marketing Analyst III',80000,90000,5),(28,'Senior Marketing Analyst',85000,95000,5),(29,'HR Rep I',40000,50000,6),(30,'HR Rep II',45000,55000,6),(31,'HR Rep III',50000,60000,6),(32,'Senior HR Rep',55000,65000,6),(33,'Facilities Rep I',25000,35000,8),(34,'Facilities Rep II',30000,40000,8),(35,'Facilities Rep III',35000,45000,8),(36,'Senior Facilities Rep',40000,50000,8),(37,'Master Mechanic I',40000,50000,8),(38,'Master Mechanic II',45000,55000,8),(39,'Master Mechanic III',50000,60000,8),(40,'Senior Master Mechanic',55000,65000,8),(41,'Security Officer I',25000,35000,9),(42,'Security Officer II',30000,40000,9),(43,'Security Officer III',35000,45000,9),(44,'Senior Security Officer',40000,50000,9),(45,'Customer Service Agent I',40000,50000,10),(46,'Customer Service Agent II',45000,55000,10),(47,'Customer Service Agent III',50000,60000,10),(48,'Lead Customer Service Agent ',55000,65000,10),(49,'Inventory Control Agent I',20000,30000,11),(50,'Inventory Control Agent II',20000,30000,11),(51,'Inventory Control Agent III',20000,30000,11),(52,'Senior Inventory Control Agent ',20000,30000,11),(53,'Financial Analyst I',64000,74000,12),(54,'Financial Analyst II',75000,85000,12),(55,'Financial Analyst III',85000,95000,12),(56,'Senior Financial Analyst',95000,105000,12),(57,'Manager of Operations',64000,74000,7),(58,'Manager of Finance',64000,74000,7),(59,'Manager of Accounting',64000,74000,7),(60,'Manager of Facilities',64000,74000,7),(61,'Manager of Sales',64000,74000,7),(62,'Manager of Marketing',64000,74000,7),(63,'Manager of Customer Support',64000,74000,7),(64,'Manager of IT',64000,74000,7),(65,'Manager of HR',64000,74000,7),(66,'Manager of Security',64000,74000,7),(67,'Manager of Inventory',64000,74000,7),(68,'President',500000,600000,7),(999,'Termination',0,1,999);
/*!40000 ALTER TABLE `position` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preserve_dup_emps`
--

DROP TABLE IF EXISTS `preserve_dup_emps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preserve_dup_emps` (
  `eid` int(11) DEFAULT NULL,
  `efn` varchar(255) DEFAULT NULL,
  `eln` varchar(255) DEFAULT NULL,
  `estreet` varchar(255) DEFAULT NULL,
  `ecity` varchar(255) DEFAULT NULL,
  `estate` varchar(255) DEFAULT NULL,
  `ezip` varchar(255) DEFAULT NULL,
  `pos_id` int(11) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `start_salary` int(11) DEFAULT NULL,
  `status_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preserve_dup_emps`
--

LOCK TABLES `preserve_dup_emps` WRITE;
/*!40000 ALTER TABLE `preserve_dup_emps` DISABLE KEYS */;
INSERT INTO `preserve_dup_emps` VALUES (14,'Joanne','Ovitt','23 South Winner Road','Enosburg Falls','VT','05450',11,45000,'2004-05-16',45000,1),(16,'Dumb','Dumber','8 North Genius Road','Plymouth','MA','02334',4,45000,'2007-11-02',45000,1),(17,'Samantha','Ovitt','88 North Ovitt Road','Lisbon','NH','03101',9,45000,'2009-09-08',45000,999999),(18,'Taylor','Bigam','23 Pants Rd','Boston','MA','04424',7,43000,'2017-08-14',43000,1),(19,'Dudlee','Dudders','21 Year Old Drive','WhereDoomed','NJ','08888',7,43000,'2011-01-16',43000,1),(20,'Foster','Dood','666 Rocky Rd','DownUnder','HI','11100',8,43000,'2016-08-03',43000,1),(22,'Kat','Killinger','509 Woods Hollow Road','Westford','VT','05494',10,43000,'2012-12-08',43000,1),(23,'Luke','Skywalker','12 Galaxy Faraway','Outerspace','NY','05403',52,45000,'2010-01-05',45000,1),(24,'Road','Kill','1 Middle Road','South Burlington','VT','21350',48,45000,'2002-08-01',45000,1),(25,'Derek','Jeter','1 Trump Plaza','New York','NY','11550',67,45000,'2012-03-15',45000,1),(26,'Pass','Go','19083 Park Place','Monopoly','AK','45650',62,45000,'2014-01-09',45000,1),(33,'David','Jones','38 South Main Street','North Brookfield','MA','01535',36,45000,'2018-01-21',45000,1),(34,'Santa','Claws','1 Pond Lane','Charlton','MA','04566',50,27500,'2016-10-12',27500,1),(35,'Johnny','Rocket','146 East Northeast Avenue','Topeka','KS','89562',20,56000,'2005-10-05',56000,1),(36,'Rachael','Hunter','987 Windy Drive','Santa Monica','CA','98960',45,42000,'2015-02-28',42000,999999),(37,'Easter','Bunny','4592 Drive Way','Orlando','FL','78523',28,88000,'2008-06-10',88000,1),(38,'Timothy','Smith','182 Brook Hill Lane','Vernon Hills','IL','60061',7,32000,'2007-10-09',32000,1),(39,'Franklin','Arts','103 Southern Street','Winooski','VT','05404',8,32000,'2015-08-06',32000,1),(40,'Anna','Caisse','102 Cushman Street','Waterbury','CT','06704',9,32000,'2004-08-02',32000,999999),(41,'Eric','Olivares','120 Vista Street','San Antonio','TX','78213',10,60000,'2004-10-07',60000,1),(42,'Thomas','Sampson','186 Devoe Avenue','Yonkers','NY','10705',11,43000,'2015-11-14',43000,1),(43,'James','Boiben','303 South Street','Multivast','TX','03784',7,43000,'2001-03-25',43000,1),(44,'Sally','Jane','312 North James Road','Alabaster','CT','06453',7,43000,'2010-12-09',43000,1),(45,'Amanda','Fintz','568 East Varsity Street','Albany','NY','13440',8,43000,'2006-04-30',43000,1),(46,'Marc','Bartalone','10284 West Advantage Avenue','Northport','CA','05832',9,43000,'2015-02-06',43000,999999),(47,'Brian','Parker','745 Falcon Way Road','Portland','WA','68440',10,43000,'2017-07-12',43000,1),(53,'Jake','Johnson','450 College Street','Burlington','VT','05401',1,35000,'2015-07-05',35000,999999),(54,'Santa','Clause','14 South Pole Dr','North Pole','ND','05404',5,40000,'2002-08-02',40000,999999),(55,'Bruce','Jones','89 Dogwood Dr','Townshend','VT','05114',9,85000,'2011-09-15',85000,999999),(56,'Guy','Getdown','69 Groovy Way','Funky Town','CA','44206',10,90000,'2014-05-22',90000,1),(57,'Sung','Fugong','65 South Union','Burlington','VT','05401',20,105000,'2015-10-23',105000,1),(68,'Bruce','Wayne','1 Wayne Manor Road','Gotham City','NY','10118',12,90000,'2011-10-17',90000,1);
/*!40000 ALTER TABLE `preserve_dup_emps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preserve_emps_contact`
--

DROP TABLE IF EXISTS `preserve_emps_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `preserve_emps_contact` (
  `eid` int(11) DEFAULT NULL,
  `contact_id` int(11) DEFAULT NULL,
  `contact` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preserve_emps_contact`
--

LOCK TABLES `preserve_emps_contact` WRITE;
/*!40000 ALTER TABLE `preserve_emps_contact` DISABLE KEYS */;
INSERT INTO `preserve_emps_contact` VALUES (14,1,'802-365-6566'),(14,2,'JoanneOvitt@neb.com'),(16,1,'802-365-9062'),(16,2,'DumbDumber@neb.com'),(17,1,'802-365-7390'),(17,2,'SamanthaOvitt@neb.com'),(18,1,'802-365-1768'),(18,2,'TaylorBigam@neb.com'),(19,1,'802-365-7205'),(19,2,'DudleeDudders@neb.com'),(20,1,'802-365-4607'),(20,2,'FosterDood@neb.com'),(22,1,'802-365-1431'),(22,2,'KatKillinger@neb.com'),(23,1,'802-365-5243'),(23,2,'LukeSkywalker@neb.com'),(24,1,'802-365-4826'),(24,2,'RoadKill@neb.com'),(25,1,'802-365-7485'),(25,2,'DerekJeter@neb.com'),(26,1,'802-365-1372'),(26,2,'PassGo@neb.com'),(33,1,'802-365-2064'),(33,2,'DavidJones@neb.com'),(34,1,'802-365-4265'),(34,2,'SantaClaws@neb.com'),(35,1,'802-365-2750'),(35,2,'JohnnyRocket@neb.com'),(36,1,'802-365-2321'),(36,2,'RachaelHunter@neb.com'),(37,1,'802-365-2496'),(37,2,'EasterBunny@neb.com'),(38,1,'802-365-9095'),(38,2,'TimothySmith@neb.com'),(39,1,'802-365-1398'),(39,2,'FranklinArts@neb.com'),(40,1,'802-365-1733'),(40,2,'AnnaCaisse@neb.com'),(41,1,'802-365-6453'),(41,2,'EricOlivares@neb.com'),(42,1,'802-365-1432'),(42,2,'ThomasSampson@neb.com'),(43,1,'802-365-5096'),(43,2,'JamesBoiben@neb.com'),(44,1,'802-365-5383'),(44,2,'SallyJane@neb.com'),(45,1,'802-365-7594'),(45,2,'AmandaFintz@neb.com'),(46,1,'802-365-2530'),(46,2,'MarcBartalone@neb.com'),(47,1,'802-365-1464'),(47,2,'BrianParker@neb.com'),(53,1,'802-365-7963'),(53,2,'JakeJohnson@neb.com'),(54,1,'802-365-7584'),(54,2,'SantaClause@neb.com'),(55,1,'802-365-8759'),(55,2,'BruceJones@neb.com'),(56,1,'802-365-3208'),(56,2,'GuyGetdown@neb.com'),(57,1,'802-365-7620'),(57,2,'SungFugong@neb.com'),(68,1,'802-365-2405'),(68,2,'BruceWayne@neb.com');
/*!40000 ALTER TABLE `preserve_emps_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'employees'
--

--
-- Dumping routines for database 'employees'
--
/*!50003 DROP PROCEDURE IF EXISTS `cleanup_dup_emps` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `cleanup_dup_emps`()
begin 
	delete from employee
	where eid in (select IDValue from ErrorEmployeeLog);
    
    delete from ErrorEmployeeLog;
    delete from ErrorAddressLog;
    delete from ErrorContactLog;
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cleanup_lowSal` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `cleanup_lowSal`()
begin 
	UPDATE EmployeePosition
	SET salary = (
		SELECT lsal FROM lowSal
		WHERE lowSal.eid=employeePosition.eid
		)
	WHERE salary<
		(
			SELECT lsal FROM Position
			WHERE EmployeePosition.pos_id=Position.pos_id
		); 
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `cleanup_salhigh` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_ALL_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `cleanup_salhigh`()
begin 
	UPDATE EmployeePosition
	SET salary = (
		SELECT hsal FROM highSal
		WHERE highsal.eid=employeePosition.eid
		)
	WHERE salary> 
		(
			SELECT hsal FROM Position
			WHERE EmployeePosition.pos_id=Position.pos_id
		); 
    
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Final view structure for view `emp_add`
--

/*!50001 DROP VIEW IF EXISTS `emp_add`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `emp_add` AS select `e`.`eid` AS `eid`,`e`.`efn` AS `efn`,`e`.`eln` AS `eln`,`a`.`estreet` AS `estreet`,`a`.`ecity` AS `ecity`,`a`.`estate` AS `estate`,`a`.`ezip` AS `ezip`,`ep`.`salary` AS `salary`,`p`.`pos_name` AS `pos_name`,`d`.`dept_name` AS `dept_name`,`c`.`contact` AS `contact` from (((((`employee` `e` join `address` `a`) join `employeeposition` `ep`) join `position` `p`) join `department` `d`) join `contact` `c` on(((`e`.`eid` = `a`.`eid`) and (`e`.`eid` = `ep`.`eid`) and (`ep`.`pos_id` = `p`.`pos_id`) and (`p`.`dept_id` = `d`.`dept_id`) and (`e`.`eid` = `c`.`eid`)))) where (`c`.`contact_id` = 2) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-21 22:37:29
